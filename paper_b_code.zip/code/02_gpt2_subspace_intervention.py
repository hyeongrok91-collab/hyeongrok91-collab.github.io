"""
GPT-2 Subspace Intervention v2: Aggressive LR + Verification
=============================================================
v1 문제: lr이 너무 작아서 loss 변화가 0.
수정: lr 10x~100x 증가 + gradient norm 모니터링 + loss 변화 확인
"""

import torch
import torch.nn.functional as F
import numpy as np
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import random
import copy
import warnings
warnings.filterwarnings('ignore')

device = 'mps' if torch.backends.mps.is_available() else 'cpu'
print(f"Device: {device}")

TARGET_LAYER = 'transformer.h.11.attn.c_attn.weight'

# ============================================================
# Data generators (compact)
# ============================================================
def gen_english(n=80):
    s = [
        "The history of mathematics can be seen as an ever-increasing series of abstractions.",
        "Machine learning provides systems with the ability to learn and improve from experience.",
        "Quantum computing leverages superposition and entanglement to process information.",
        "Statistical mechanics relates microscopic atomic properties to macroscopic bulk properties.",
        "The periodic table organizes elements by atomic number and electron configuration.",
        "Neural networks are computing systems inspired by biological brain architecture.",
        "Thermodynamics deals with heat, work, temperature, and their relation to energy.",
        "The Renaissance sparked new interest in classical Greek and Roman art and literature.",
        "Cryptography enables secure communication in the presence of adversarial behavior.",
        "Photosynthesis converts light energy into chemical energy for plant growth.",
        "Plate tectonics describes the motion of large plates of Earth's lithosphere.",
        "The Enlightenment dominated European intellectual thought in the 18th century.",
        "Cognitive psychology studies attention, memory, language use, and problem solving.",
        "Climate change involves long-term shifts in temperatures driven by human activity.",
        "Conservation biology studies preservation and restoration of natural environments.",
        "Urbanization is the population shift from rural areas to cities and towns.",
        "Genetics reveals how traits pass from parents to offspring through DNA sequences.",
        "Robotics combines engineering and computer science to design intelligent machines.",
        "Natural language processing enables computers to understand human language.",
        "General relativity describes gravity as curvature of spacetime caused by mass.",
        "The development of writing systems was a key achievement in human civilization.",
        "Molecular biology studies the molecular basis of biological activity in cells.",
        "Supply and demand determines the equilibrium price in competitive markets.",
        "Archaeological discoveries reshape understanding of ancient civilizations.",
        "The global economy is interconnected through trade and technology exchange.",
        "Biodiversity encompasses genetic, species, and ecosystem diversity on Earth.",
        "The philosophy of science examines foundations and methods of scientific inquiry.",
        "The human genome project mapped all genes providing valuable medical information.",
        "Artificial intelligence research has seen rapid growth due to deep learning advances.",
        "Democratic governance relies on the principle of consent of the governed population.",
    ]
    random.shuffle(s)
    return s[:n]

def gen_code(n=80):
    s = [
        "def fibonacci(n):\n    if n <= 1: return n\n    return fibonacci(n-1) + fibonacci(n-2)\nprint([fibonacci(i) for i in range(15)])",
        "class DataLoader:\n    def __init__(self, data, bs=32):\n        self.data, self.bs = data, bs\n    def __iter__(self):\n        for i in range(0, len(self.data), self.bs):\n            yield self.data[i:i+self.bs]",
        "import numpy as np\ndef eigensolve(A):\n    vals, vecs = np.linalg.eigh(A)\n    return vals[::-1], vecs[:, ::-1]",
        "def quicksort(arr):\n    if len(arr) <= 1: return arr\n    p = arr[len(arr)//2]\n    return quicksort([x for x in arr if x<p]) + [x for x in arr if x==p] + quicksort([x for x in arr if x>p])",
        "@dataclass\nclass Config:\n    lr: float = 1e-3\n    batch_size: int = 32\n    epochs: int = 100\n    hidden: int = 512",
        "import torch.nn as nn\nclass MLP(nn.Module):\n    def __init__(self, d_in, d_h, d_out):\n        super().__init__()\n        self.net = nn.Sequential(nn.Linear(d_in,d_h), nn.ReLU(), nn.Linear(d_h,d_out))\n    def forward(self, x): return self.net(x)",
        "from collections import Counter\ndef top_words(text, k=10):\n    return Counter(text.lower().split()).most_common(k)",
        "def binary_search(arr, target):\n    lo, hi = 0, len(arr)-1\n    while lo <= hi:\n        mid = (lo+hi)//2\n        if arr[mid] == target: return mid\n        elif arr[mid] < target: lo = mid+1\n        else: hi = mid-1\n    return -1",
        "class LRUCache:\n    def __init__(self, cap):\n        self.cache = OrderedDict()\n        self.cap = cap\n    def get(self, key):\n        if key in self.cache:\n            self.cache.move_to_end(key)\n            return self.cache[key]\n        return -1",
        "def merge_sort(arr):\n    if len(arr) <= 1: return arr\n    mid = len(arr)//2\n    return merge(merge_sort(arr[:mid]), merge_sort(arr[mid:]))",
        "import pandas as pd\ndf = pd.read_csv('data.csv')\ndf['ratio'] = df['val'] / df['total']\nprint(df.groupby('cat').agg({'ratio': ['mean', 'std']}))",
        "class Graph:\n    def __init__(self): self.adj = defaultdict(list)\n    def add(self, u, v): self.adj[u].append(v)\n    def bfs(self, s):\n        vis, q = {s}, deque([s])\n        while q:\n            for nb in self.adj[q.popleft()]:\n                if nb not in vis: vis.add(nb); q.append(nb)",
        "async def fetch(url):\n    async with aiohttp.ClientSession() as s:\n        async with s.get(url) as r:\n            return await r.json()",
        "def matrix_mul(A, B):\n    n, m, k = len(A), len(B[0]), len(B)\n    return [[sum(A[i][l]*B[l][j] for l in range(k)) for j in range(m)] for i in range(n)]",
        "def retry(n=3, delay=1):\n    def dec(f):\n        @wraps(f)\n        def w(*a,**k):\n            for i in range(n):\n                try: return f(*a,**k)\n                except: sleep(delay)\n            raise RuntimeError\n        return w\n    return dec",
    ]
    random.shuffle(s)
    return s[:n]

def gen_korean(n=40):
    s = [
        "인공지능의 발전은 현대 사회의 모든 분야에 걸쳐 근본적인 변화를 가져오고 있다.",
        "대한민국의 반도체 산업은 글로벌 시장에서 핵심적인 위치를 차지하고 있다.",
        "양자컴퓨팅 기술은 기존 컴퓨터로는 풀기 어려운 복잡한 문제들을 해결할 수 있다.",
        "한국어 자연어처리 연구는 최근 몇 년간 급격한 발전을 이루었다.",
        "기후변화는 전 세계적으로 가장 심각한 환경 문제 중 하나로 인식되고 있다.",
        "디지털 전환은 기업의 비즈니스 모델과 운영 방식을 변화시키고 있다.",
        "생명공학 기술의 발전은 의약품 개발에 혁명적인 변화를 가져오고 있다.",
        "빅데이터 분석은 대용량의 데이터에서 유의미한 패턴을 추출하는 기술이다.",
        "한국의 영화 산업은 세계적인 주목을 받으며 한류 문화를 이끌고 있다.",
        "블록체인 기술은 거래의 투명성과 보안성을 보장하는 분산원장 기술이다.",
        "서울은 대한민국의 수도이자 경제 문화의 중심지이다.",
        "한국의 교통 인프라는 고속철도와 지하철을 중심으로 구축되어 있다.",
        "재생에너지 기술의 보급은 탄소 중립 목표 달성의 핵심 과제이다.",
        "한국의 스타트업 생태계는 핀테크 분야에서 혁신적인 기업들이 등장하고 있다.",
        "조선시대의 과학 기술은 세계적 수준이었으며 다양한 기기가 발명되었다.",
        "한국 경제는 수출 주도형 성장 모델을 기반으로 발전해왔다.",
        "사물인터넷 기술은 일상 기기들을 연결하여 자동화와 효율성을 높이고 있다.",
        "로봇 공학의 발전은 제조업과 서비스 산업 모두에서 혁신을 가져오고 있다.",
        "한국의 우주 산업은 누리호 발사 성공으로 새로운 전환점을 맞이하였다.",
        "한국의 음식 문화는 발효식품을 중심으로 세계적 인정을 받고 있다.",
    ]
    random.shuffle(s)
    return s[:n]

def gen_json(n=80):
    s = []
    keys = ["model", "lr", "batch", "epochs", "hidden", "layers", "dropout",
            "decay", "optim", "sched", "act", "maxlen", "vocab", "heads", "embed"]
    for i in range(n):
        random.shuffle(keys)
        nk = random.randint(4, 7)
        pairs = []
        for k in keys[:nk]:
            if k in ("lr", "decay", "dropout"):
                v = f"{random.uniform(1e-4,0.1):.5f}"
            elif k in ("batch", "hidden", "layers", "heads", "epochs", "maxlen", "vocab", "embed"):
                v = str(random.choice([8,16,32,64,128,256,512,768,1024]))
            else:
                v = f'"{random.choice(["adam","sgd","adamw","gelu","relu","tf"])}"'
            pairs.append(f'"{k}":{v}')
        s.append("{" + ",".join(pairs) + "}")
    return s[:n]

# ============================================================
# Core
# ============================================================
def setup():
    print("Loading GPT-2...")
    model = GPT2LMHeadModel.from_pretrained('gpt2').to(device)
    tok = GPT2Tokenizer.from_pretrained('gpt2')
    tok.pad_token = tok.eos_token
    model.eval()
    return model, tok

def get_param(model):
    for n, p in model.named_parameters():
        if n == TARGET_LAYER: return p
    return None

def collect_grads(model, texts, param, tok, max_len=64):
    grads = []
    for t in texts:
        toks = tok(t, return_tensors='pt', max_length=max_len, truncation=True).to(device)
        if toks['input_ids'].shape[1] < 2: continue
        model.zero_grad()
        out = model(**toks, labels=toks['input_ids'])
        out.loss.backward()
        grads.append(param.grad.flatten().detach().cpu().clone())
    return torch.stack(grads) if grads else None

def compute_eigensystem(G_base, G_task):
    n = G_base.shape[0]
    K = (G_base @ G_base.T) / n
    eigvals, eigvecs = torch.linalg.eigh(K)
    idx = torch.argsort(eigvals, descending=True)
    eigvals = eigvals[idx]
    eigvecs = eigvecs[:, idx]
    pos = eigvals > eigvals[0] * 1e-6
    eigvals = eigvals[pos]
    eigvecs = eigvecs[:, pos]
    
    sigmas = torch.sqrt(n * eigvals.clamp(min=1e-12))
    V = (G_base.T @ eigvecs) / sigmas.unsqueeze(0)
    
    g_task = G_task.mean(dim=0)
    proj = V.T @ g_task
    c_sq = proj**2
    
    return eigvals, V, c_sq

def evaluate(model, tok, texts, max_n=8):
    model.eval()
    losses = []
    with torch.no_grad():
        for t in texts[:max_n]:
            toks_d = tok(t, return_tensors='pt', max_length=64, truncation=True).to(device)
            if toks_d['input_ids'].shape[1] < 2: continue
            out = model(**toks_d, labels=toks_d['input_ids'])
            losses.append(out.loss.item())
    return np.mean(losses) if losses else float('inf')

def subspace_finetune(model, tok, texts_train, texts_eval, V_sub, n_steps=100, lr=1e-2):
    """
    Constrained fine-tuning in subspace V_sub (P × k).
    Uses accumulated mini-batches for stability.
    """
    model_ft = copy.deepcopy(model)
    param = get_param(model_ft)
    P = param.numel()
    orig_shape = param.shape
    
    for n, p in model_ft.named_parameters():
        p.requires_grad_(n == TARGET_LAYER)
    
    V_dev = V_sub.to(device)
    
    losses = []
    grad_norms = []
    
    # Initial eval
    init_loss = evaluate(model_ft, tok, texts_eval)
    losses.append((0, init_loss))
    
    for step in range(1, n_steps + 1):
        # Accumulate gradient over mini-batch of 4 texts
        model_ft.zero_grad()
        batch_loss = 0
        n_valid = 0
        
        for _ in range(4):
            idx = random.randint(0, len(texts_train) - 1)
            toks_d = tok(texts_train[idx], return_tensors='pt', max_length=64, truncation=True).to(device)
            if toks_d['input_ids'].shape[1] < 2: continue
            out = model_ft(**toks_d, labels=toks_d['input_ids'])
            (out.loss / 4).backward()
            batch_loss += out.loss.item()
            n_valid += 1
        
        if n_valid == 0: continue
        
        with torch.no_grad():
            g = param.grad.flatten()
            g_norm = g.norm().item()
            
            # Project to subspace
            coeffs = V_dev.T @ g
            g_proj = V_dev @ coeffs
            proj_norm = g_proj.norm().item()
            
            # Update
            param.data -= lr * g_proj.view(orig_shape)
            grad_norms.append((g_norm, proj_norm))
        
        # Eval every 10 steps
        if step % 10 == 0 or step == 1:
            el = evaluate(model_ft, tok, texts_eval)
            losses.append((step, el))
    
    return losses, grad_norms

# ============================================================
# Main
# ============================================================
def run():
    random.seed(42)
    torch.manual_seed(42)
    np.random.seed(42)
    
    model, tok = setup()
    param = get_param(model)
    P = param.numel()
    print(f"Target: {TARGET_LAYER} ({P:,} params)")
    
    english = gen_english(40)
    domains = {'Code': gen_code(20), 'Korean': gen_korean(18), 'JSON': gen_json(20)}
    
    print("\n[1] Base eigensystem...")
    G_base = collect_grads(model, english, param, tok)
    print(f"    G_base: {G_base.shape}")
    
    K = 10
    N_STEPS = 100
    N_SEEDS = 5
    
    # First: calibrate LR by checking gradient norms
    print("\n[2] Calibrating learning rate...")
    # Quick gradient norm check
    model.zero_grad()
    toks_d = tok(english[0], return_tensors='pt', max_length=64, truncation=True).to(device)
    out = model(**toks_d, labels=toks_d['input_ids'])
    out.loss.backward()
    full_grad_norm = param.grad.flatten().norm().item()
    print(f"    Full gradient norm: {full_grad_norm:.6f}")
    print(f"    Param norm: {param.data.flatten().norm().item():.4f}")
    
    # LR should make step size ~ 0.1% of param norm
    param_norm = param.data.flatten().norm().item()
    target_step = 0.001 * param_norm  # 0.1% of norm per step
    LR = target_step / (full_grad_norm + 1e-12)
    LR = max(LR, 1e-3)  # at least 1e-3
    LR = min(LR, 1.0)   # at most 1.0
    print(f"    Calibrated LR: {LR:.4f}")
    
    all_results = {}
    
    for domain_name, texts in domains.items():
        print(f"\n{'='*60}")
        print(f"Domain: {domain_name}")
        print(f"{'='*60}")
        
        n_train = max(len(texts) - 5, int(0.7 * len(texts)))
        texts_train = texts[:n_train]
        texts_eval = texts[n_train:]
        
        G_task = collect_grads(model, texts, param, tok)
        if G_task is None: continue
        
        eigvals, V, c_sq = compute_eigensystem(G_base, G_task)
        n_eig = len(eigvals)
        k = min(K, n_eig // 2)
        print(f"  Eigvals: {n_eig}, k={k}")
        
        V_topk = V[:, :k].clone()
        
        c_sq_np = c_sq.numpy()
        opt_idx = np.argsort(c_sq_np)[::-1][:k].copy()
        V_opt = V[:, opt_idx].clone()
        
        overlap = len(set(range(k)) & set(opt_idx.tolist()))
        print(f"  Top-k:     {list(range(k))}")
        print(f"  Optimal:   {sorted(opt_idx.tolist())}")
        print(f"  Overlap:   {overlap}/{k}")
        
        # Report c_sq distribution
        c_sq_sorted = np.sort(c_sq_np)[::-1]
        topk_energy = c_sq_sorted[:k].sum() / c_sq_sorted.sum() *100
        print(f"  Top-{k} energy: {topk_energy:.1f}% of total |c|²")
        print(f"  Optimal energy: {c_sq_np[opt_idx].sum()/c_sq_np.sum()*100:.1f}%")
        
        domain_results = {'topk': [], 'optimal': [], 'random': []}
        
        for seed in range(N_SEEDS):
            random.seed(seed * 7 + 13)
            torch.manual_seed(seed * 7 + 13)
            
            print(f"\n  Seed {seed}:")
            
            # (A) Top-k
            res_A, gn_A = subspace_finetune(model, tok, texts_train, texts_eval, V_topk, N_STEPS, LR)
            l0, lf = res_A[0][1], res_A[-1][1]
            delta_A = l0 - lf
            print(f"    (A) Top-k:   {l0:.4f} → {lf:.4f} (Δ={delta_A:.4f})")
            domain_results['topk'].append(res_A)
            
            # (B) Optimal
            res_B, gn_B = subspace_finetune(model, tok, texts_train, texts_eval, V_opt, N_STEPS, LR)
            l0, lf = res_B[0][1], res_B[-1][1]
            delta_B = l0 - lf
            print(f"    (B) Optimal: {l0:.4f} → {lf:.4f} (Δ={delta_B:.4f})")
            domain_results['optimal'].append(res_B)
            
            # (C) Random
            V_rand = torch.randn(P, k)
            V_rand, _ = torch.linalg.qr(V_rand)
            res_C, gn_C = subspace_finetune(model, tok, texts_train, texts_eval, V_rand, N_STEPS, LR)
            l0, lf = res_C[0][1], res_C[-1][1]
            delta_C = l0 - lf
            print(f"    (C) Random:  {l0:.4f} → {lf:.4f} (Δ={delta_C:.4f})")
            domain_results['random'].append(res_C)
            
            # Gradient norm info (from last run)
            if gn_A:
                avg_full = np.mean([x[0] for x in gn_A])
                avg_proj = np.mean([x[1] for x in gn_A])
                print(f"    Grad norms: full={avg_full:.6f}, proj={avg_proj:.6f}, ratio={avg_proj/avg_full:.4f}")
        
        all_results[domain_name] = domain_results
    
    # ============================================================
    # Summary
    # ============================================================
    print("\n" + "=" * 65)
    print("INTERVENTION SUMMARY")
    print("=" * 65)
    
    for domain, res in all_results.items():
        finals_A = [r[-1][1] for r in res['topk']]
        finals_B = [r[-1][1] for r in res['optimal']]
        finals_C = [r[-1][1] for r in res['random']]
        
        mean_A, std_A = np.mean(finals_A), np.std(finals_A)
        mean_B, std_B = np.mean(finals_B), np.std(finals_B)
        mean_C, std_C = np.mean(finals_C), np.std(finals_C)
        
        B_wins_A = sum(1 for a, b in zip(finals_A, finals_B) if b < a)
        A_wins_C = sum(1 for a, c in zip(finals_A, finals_C) if a < c)
        B_wins_C = sum(1 for c, b in zip(finals_C, finals_B) if b < c)
        
        print(f"\n  {domain}:")
        print(f"    Top-k:    {mean_A:.4f} ± {std_A:.4f}")
        print(f"    Optimal:  {mean_B:.4f} ± {std_B:.4f}")
        print(f"    Random:   {mean_C:.4f} ± {std_C:.4f}")
        print(f"    Opt beat Top-k: {B_wins_A}/{N_SEEDS} | Top-k beat Rnd: {A_wins_C}/{N_SEEDS} | Opt beat Rnd: {B_wins_C}/{N_SEEDS}")
        
        if mean_B < mean_A and B_wins_A >= 3:
            print(f"    → ✅ Source-guided WINS ({(mean_A-mean_B)/mean_A*100:.1f}% better)")
        elif abs(mean_B - mean_A) < 0.01:
            print(f"    → ⚠️ No significant difference")
        else:
            print(f"    → ❌ Top-k wins")
    
    # ============================================================
    # Plot
    # ============================================================
    n_dom = len(all_results)
    fig, axes = plt.subplots(1, n_dom, figsize=(6*n_dom, 5))
    if n_dom == 1: axes = [axes]
    
    for ax, (domain, res) in zip(axes, all_results.items()):
        for label, key, color, ls in [
            ('Top-k (std LoRA)', 'topk', '#2196F3', '-'),
            ('|c²|-optimal (source-guided)', 'optimal', '#F44336', '-'),
            ('Random subspace', 'random', '#9E9E9E', '--'),
        ]:
            step_data = {}
            for curve in res[key]:
                for step, loss in curve:
                    step_data.setdefault(step, []).append(loss)
            
            steps = sorted(step_data.keys())
            means = [np.mean(step_data[s]) for s in steps]
            stds = [np.std(step_data[s]) for s in steps]
            
            ax.plot(steps, means, color=color, linestyle=ls, linewidth=2, label=label)
            ax.fill_between(steps, [m-s for m,s in zip(means,stds)],
                          [m+s for m,s in zip(means,stds)], alpha=0.15, color=color)
        
        ax.set_xlabel('Step')
        ax.set_ylabel('Held-out Loss')
        ax.set_title(f'{domain}')
        ax.legend(fontsize=7)
        ax.grid(True, alpha=0.3)
    
    plt.suptitle('GPT-2 Subspace Intervention (Layer 11 c_attn)', fontsize=12, fontweight='bold')
    plt.tight_layout()
    
    save = '/Users/hyeongrok/Documents/UAF, 기하- 대수적 프레임 워크/uaf math/polytope_research/paper_c/gpt2_intervention_v2.png'
    plt.savefig(save, dpi=150, bbox_inches='tight')
    print(f"\nPlot: {save}")

if __name__ == '__main__':
    run()
