"""
α-Crossover CONTROLLED Experiment
===================================

핵심 차이: α를 synthetic으로 직접 제어.
자연 데이터에서 α > 0.5를 "찾기"가 아니라 α를 "만든다".

Design:
  1. Random MLP 학습 → θ* 고정 → Jacobian J 계산 → M_T = J^T J eigendecompose
  2. Target function f* = Ψ(θ*) + residual 로 설정
  3. Residual을 M_T eigenbasis에서 직접 구성:
     - α=0:   c_i ∝ λ_i^{1/2}     (top에 집중)
     - α=0.3: c_i ∝ λ_i^{0.2}     (약간 top)
     - α=0.5: c_i ∝ 1             (균등)
     - α=0.7: c_i ∝ λ_i^{-0.2}   (bottom에 집중)
     - α=1.0: c_i ∝ λ_i^{-1/2}   (강하게 bottom)
  4. 각 α에서 top-k vs bottom-k vs |c_i|²-optimal 비교
  5. Crossover 확인: α > 0.5에서 bottom-k가 이기는가?

This is a DIRECT test of the theory — no ambiguity.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

torch.manual_seed(42)
np.random.seed(42)

# ============================================================
# 1. Model & Jacobian
# ============================================================
class TinyMLP(nn.Module):
    def __init__(self, d_in=20, hidden=32, d_out=10):
        super().__init__()
        self.fc1 = nn.Linear(d_in, hidden, bias=False)
        self.fc2 = nn.Linear(hidden, hidden, bias=False)
        self.fc3 = nn.Linear(hidden, d_out, bias=False)
    
    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)

def compute_jacobian(model, x):
    """Full Jacobian DΨ(θ*) at a single input x. Shape: (d_out, P)"""
    model.zero_grad()
    f = model(x.unsqueeze(0)).squeeze(0)  # (d_out,)
    d_out = f.shape[0]
    
    jac_rows = []
    for i in range(d_out):
        model.zero_grad()
        f = model(x.unsqueeze(0)).squeeze(0)
        f[i].backward(retain_graph=(i < d_out - 1))
        row = torch.cat([p.grad.flatten() for p in model.parameters()])
        jac_rows.append(row.clone())
    
    return torch.stack(jac_rows)  # (d_out, P)

def compute_avg_jacobian(model, X, n_samples=50):
    """Average Jacobian over multiple inputs for stability."""
    jacs = []
    for i in range(min(n_samples, len(X))):
        jacs.append(compute_jacobian(model, X[i]))
    return torch.stack(jacs).mean(dim=0)  # (d_out, P)

# ============================================================
# 2. Construct Controlled Residual
# ============================================================
def make_controlled_residual(eigenvalues, eigenvectors_U, alpha, scale=1.0):
    """
    Construct residual e_T in function space such that:
      c_i = <G^{1/2} e_T, u_i> = λ_i^{1/2 - α} * g_hat_i
    
    With g_hat_i ≈ uniform, so c_i ∝ λ_i^{1/2-α}
    
    Returns: c_i coefficients
    """
    k = len(eigenvalues)
    # g_hat_i ~ N(0,1), fixed for reproducibility
    torch.manual_seed(123)
    g_hat = torch.randn(k)
    g_hat = g_hat / g_hat.norm()  # normalize
    
    # c_i = λ_i^{1/2 - α} * g_hat_i
    lam = eigenvalues.clamp(min=1e-10)
    c = lam.pow(0.5 - alpha) * g_hat * scale
    
    return c.detach()

# ============================================================
# 3. Subspace Selection Analysis
# ============================================================
def analyze_subspace(c_true, k):
    """
    Given true residual coefficients c_i (sorted by eigenvalue descending),
    compare:
      - top-k: first k indices
      - bottom-k: last k indices
      - optimal-k: k indices with largest |c_i|²
    
    Metric: fraction of total ||c||² captured
    """
    c2 = c_true ** 2
    total = c2.sum().item()
    if total < 1e-20:
        return 0, 0, 0
    
    n = len(c_true)
    
    # top-k
    top_captured = c2[:k].sum().item() / total
    
    # bottom-k
    bot_captured = c2[-k:].sum().item() / total
    
    # optimal-k
    _, opt_idx = torch.topk(c2, min(k, n))
    opt_captured = c2[opt_idx].sum().item() / total
    
    return top_captured, bot_captured, opt_captured

# ============================================================
# 4. Run Controlled Experiment
# ============================================================
def run_controlled_experiment():
    print("=" * 65)
    print("CONTROLLED α-Crossover Experiment")
    print("α is directly set, not estimated — this is a DIRECT theory test")
    print("=" * 65)
    
    # Create model and random data
    d_in, hidden, d_out = 20, 32, 10
    model = TinyMLP(d_in, hidden, d_out)
    
    # Random "training" to get a non-trivial θ*
    X = torch.randn(200, d_in)
    y = torch.randint(0, d_out, (200,))
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
    for _ in range(100):
        optimizer.zero_grad()
        loss = F.cross_entropy(model(X), y)
        loss.backward()
        optimizer.step()
    
    print(f"\nModel: {sum(p.numel() for p in model.parameters())} parameters")
    
    # Compute average Jacobian
    print("Computing Jacobian...")
    J = compute_avg_jacobian(model, X, n_samples=50)  # (d_out, P)
    
    # Task metric M_T = J^T J  (using G_T = I for simplicity)
    M_T = J.T @ J  # (P, P)
    
    # Eigendecomposition
    eigenvalues, eigenvectors = torch.linalg.eigh(M_T)
    idx = torch.argsort(eigenvalues, descending=True)
    eigenvalues = eigenvalues[idx]
    eigenvectors = eigenvectors[:, idx]
    
    # Keep meaningful eigenvalues
    n_keep = (eigenvalues > eigenvalues[0] * 1e-6).sum().item()
    n_keep = max(n_keep, 20)
    eigenvalues = eigenvalues[:n_keep]
    eigenvectors = eigenvectors[:, :n_keep]
    
    print(f"Kept {n_keep} eigenvalues (max={eigenvalues[0]:.4f}, min={eigenvalues[-1]:.6f})")
    print(f"Condition number: {eigenvalues[0]/eigenvalues[-1]:.1f}")
    
    # ============================================================
    # Test α values spanning the crossover
    # ============================================================
    alphas = [-0.5, 0.0, 0.25, 0.5, 0.75, 1.0, 1.5]
    k_values = [3, 5, 10]
    
    print(f"\n{'α':>6} | {'Prediction':>12} | ", end="")
    for k in k_values:
        print(f"  k={k}: top/bot/opt  |", end="")
    print(f" {'Winner(k=5)':>12} | {'Match?':>6}")
    print("-" * 110)
    
    results = {}
    
    for alpha in alphas:
        # Construct residual with this α
        c = make_controlled_residual(eigenvalues, eigenvectors, alpha)
        
        predicted = "top-k" if alpha < 0.5 else ("neutral" if alpha == 0.5 else "bottom-k")
        
        row_results = {}
        winner_k5 = ""
        
        print(f"{alpha:>6.2f} | {predicted:>12} | ", end="")
        
        for k in k_values:
            top, bot, opt = analyze_subspace(c, k)
            row_results[k] = {'top': top, 'bot': bot, 'opt': opt}
            print(f"  {top:.3f}/{bot:.3f}/{opt:.3f} |", end="")
            
            if k == 5:
                winner_k5 = "top-k" if top > bot else "bottom-k"
        
        match = "✅" if (alpha < 0.5 and winner_k5 == "top-k") or \
                        (alpha > 0.5 and winner_k5 == "bottom-k") or \
                        alpha == 0.5 else "❌"
        
        print(f" {winner_k5:>12} | {match:>6}")
        
        results[alpha] = {
            'c': c.numpy(),
            'subspaces': row_results,
            'winner': winner_k5,
            'predicted': predicted,
        }
    
    # ============================================================
    # Verify the EXACT crossover point
    # ============================================================
    print("\n" + "=" * 65)
    print("CROSSOVER SCAN: Fine-grained α sweep around 0.5")
    print("=" * 65)
    
    fine_alphas = np.linspace(0.0, 1.0, 21)
    k_test = 5
    top_fractions = []
    bot_fractions = []
    
    for alpha in fine_alphas:
        c = make_controlled_residual(eigenvalues, eigenvectors, alpha)
        top, bot, opt = analyze_subspace(c, k_test)
        top_fractions.append(top)
        bot_fractions.append(bot)
    
    # Find crossover
    top_arr = np.array(top_fractions)
    bot_arr = np.array(bot_fractions)
    crossover_idx = np.argmin(np.abs(top_arr - bot_arr))
    crossover_alpha = fine_alphas[crossover_idx]
    
    print(f"\nCrossover point (top-k = bottom-k): α ≈ {crossover_alpha:.2f}")
    print(f"Theory predicts: α = 0.50")
    print(f"Error: |{crossover_alpha:.2f} - 0.50| = {abs(crossover_alpha - 0.50):.2f}")
    
    if abs(crossover_alpha - 0.50) < 0.15:
        print("→ ✅ THEORY CONFIRMED: crossover near α = 0.5")
    else:
        print(f"→ ❌ THEORY VIOLATED: crossover at α = {crossover_alpha:.2f}, not 0.5")
    
    # ============================================================
    # Plot
    # ============================================================
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    # Plot 1: |c_i|² distribution for different α
    ax1 = axes[0]
    plot_alphas = [0.0, 0.25, 0.5, 0.75, 1.0]
    colors = ['#2196F3', '#4CAF50', '#FF9800', '#F44336', '#9C27B0']
    for alpha, color in zip(plot_alphas, colors):
        c = make_controlled_residual(eigenvalues, eigenvectors, alpha)
        c2 = c.numpy()**2
        ax1.semilogy(range(len(c2)), c2, 'o-', color=color, 
                     label=f'α={alpha:.1f}', markersize=3, alpha=0.8)
    ax1.set_xlabel('Eigenvalue index i (sorted by λ descending)')
    ax1.set_ylabel('|c_i|²')
    ax1.set_title('Residual Coefficient Distribution')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    ax1.axvline(x=k_test-0.5, color='gray', linestyle='--', alpha=0.5, label=f'k={k_test}')
    
    # Plot 2: Top-k vs Bottom-k as function of α
    ax2 = axes[1]
    ax2.plot(fine_alphas, top_fractions, 'b-o', label='Top-k captured', markersize=4)
    ax2.plot(fine_alphas, bot_fractions, 'r-s', label='Bottom-k captured', markersize=4)
    ax2.axvline(x=0.5, color='gray', linestyle='--', alpha=0.7, label='Theory crossover (α=0.5)')
    ax2.axvline(x=crossover_alpha, color='green', linestyle=':', alpha=0.7, 
                label=f'Empirical crossover (α={crossover_alpha:.2f})')
    ax2.set_xlabel('α (source condition parameter)')
    ax2.set_ylabel(f'Fraction of ||c||² captured (k={k_test})')
    ax2.set_title('THE CROSSOVER: Top-k vs Bottom-k')
    ax2.legend(fontsize=8)
    ax2.grid(True, alpha=0.3)
    ax2.fill_between(fine_alphas, 0, 1, where=np.array(fine_alphas)<0.5, 
                     alpha=0.05, color='blue', label='Top-k region')
    ax2.fill_between(fine_alphas, 0, 1, where=np.array(fine_alphas)>0.5, 
                     alpha=0.05, color='red', label='Bottom-k region')
    
    # Plot 3: Bar chart for selected α values
    ax3 = axes[2]
    bar_alphas = [0.0, 0.25, 0.5, 0.75, 1.0]
    x = np.arange(len(bar_alphas))
    width = 0.25
    
    tops = [results[a]['subspaces'][5]['top'] for a in bar_alphas]
    bots = [results[a]['subspaces'][5]['bot'] for a in bar_alphas]
    opts = [results[a]['subspaces'][5]['opt'] for a in bar_alphas]
    
    ax3.bar(x - width, tops, width, label='Top-k', color='steelblue')
    ax3.bar(x, bots, width, label='Bottom-k', color='coral')
    ax3.bar(x + width, opts, width, label='|c²|-optimal', color='forestgreen', alpha=0.7)
    
    ax3.set_xlabel('α')
    ax3.set_ylabel(f'Fraction captured (k={k_test})')
    ax3.set_title('Subspace Selection vs α')
    ax3.set_xticks(x)
    ax3.set_xticklabels([f'α={a}' for a in bar_alphas])
    ax3.legend()
    ax3.grid(True, alpha=0.3, axis='y')
    
    # Annotate winners
    for i, a in enumerate(bar_alphas):
        winner = "TOP" if tops[i] > bots[i] else "BOT"
        color = 'blue' if winner == "TOP" else 'red'
        ax3.annotate(winner, xy=(i, max(tops[i], bots[i]) + 0.02),
                    ha='center', fontsize=9, color=color, fontweight='bold')
    
    plt.tight_layout()
    save_path = '/Users/hyeongrok/Documents/UAF, 기하- 대수적 프레임 워크/uaf math/polytope_research/paper_c/alpha_crossover_controlled.png'
    plt.savefig(save_path, dpi=150)
    print(f"\nPlot saved: {save_path}")
    
    return results, crossover_alpha

if __name__ == '__main__':
    results, crossover = run_controlled_experiment()
