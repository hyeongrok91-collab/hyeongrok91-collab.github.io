#!/usr/bin/env python3
"""
Gold anchor experiment for paper_b (Section "Bridge problem"):

Goal
  - Numerically anchor the *local bridge* object η_T(k) by showing that:
      (i) in a smooth nonlinear model, the best k-dim *local* improvement
          matches the linearized prediction (η_T(k) tail),
     (ii) the M_T-top-k subspace beats a random k-subspace under the same
          local radius constraint.

Setup
  - Teacher-student regression with squared loss (so G_T = I).
  - Student is a 1-hidden-layer tanh MLP parameterized by a single vector θ.
  - All bridge quantities are measured on held-out data.

Outputs
  - Prints a compact table for k in K_LIST.
  - Writes JSON to sweep_outputs/ and a PNG plot to figures/ (optional).
"""

import json
import math
import os
import time

import numpy as np
import torch


if __name__ == "__main__":
    # ============================================================
    # Config (env-overridable)
    # ============================================================
    SEED = int(os.getenv("SEED", "0"))

    DEVICE = os.getenv("DEVICE", "cpu").strip().lower()
    if DEVICE == "auto":
        if torch.cuda.is_available():
            DEVICE = "cuda"
        elif getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
            DEVICE = "mps"
        else:
            DEVICE = "cpu"

    DTYPE = torch.float64

    D_IN = int(os.getenv("D_IN", "16"))
    D_OUT = int(os.getenv("D_OUT", "4"))
    W_TEACHER = int(os.getenv("W_TEACHER", "32"))
    W_STUDENT = int(os.getenv("W_STUDENT", "32"))

    N_TRAIN = int(os.getenv("N_TRAIN", "512"))
    N_TEST = int(os.getenv("N_TEST", "256"))

    TRAIN_STEPS = int(os.getenv("TRAIN_STEPS", "1500"))
    LR = float(os.getenv("LR", "2e-2"))
    WEIGHT_DECAY = float(os.getenv("WEIGHT_DECAY", "0.0"))

    SUBSPACE_STEPS = int(os.getenv("SUBSPACE_STEPS", "250"))
    SUBSPACE_LR = float(os.getenv("SUBSPACE_LR", "8e-2"))

    RADIUS_MULT = float(os.getenv("RADIUS_MULT", "1.5"))
    RADIUS_MIN = float(os.getenv("RADIUS_MIN", "1e-6"))

    K_LIST_RAW = os.getenv("K_LIST", "0,1,2,4,8,16,32,64")
    K_LIST = [int(x) for x in K_LIST_RAW.split(",") if x.strip()]
    K_LIST = sorted(set(K_LIST))

    M2_SAMPLES = int(os.getenv("M2_SAMPLES", "64"))
    M2_SAFETY = float(os.getenv("M2_SAFETY", "2.0"))

    SAVE_PLOT = int(os.getenv("SAVE_PLOT", "1"))
    OUT_JSON = os.getenv("OUT_JSON", f"sweep_outputs/local_bridge_anchor_seed{SEED}.json").strip()
    OUT_PNG = os.getenv("OUT_PNG", f"figures/local_bridge_anchor_seed{SEED}.png").strip()

    torch.manual_seed(SEED)
    np.random.seed(SEED)

    device = torch.device(DEVICE)
    print("=" * 78)
    print("GOLD ANCHOR: local bridge η_T(k) + subspace intervention (tanh MLP, MSE)")
    print("=" * 78)
    print(f"seed={SEED} device={device.type} dtype=float64")
    print(f"d_in={D_IN} d_out={D_OUT} w_teacher={W_TEACHER} w_student={W_STUDENT}")
    print(f"train={N_TRAIN} test={N_TEST} train_steps={TRAIN_STEPS} lr={LR:g}")
    print(f"subspace_steps={SUBSPACE_STEPS} subspace_lr={SUBSPACE_LR:g}")
    print(f"K_LIST={K_LIST}")
    print()

    # ============================================================
    # Parameter layout: θ = [W1, b1, W2, b2]
    #   W1: (w, d_in)   b1: (w,)
    #   W2: (d_out, w)  b2: (d_out,)
    # ============================================================
    P_TEACH = W_TEACHER * D_IN + W_TEACHER + D_OUT * W_TEACHER + D_OUT
    P_STUD = W_STUDENT * D_IN + W_STUDENT + D_OUT * W_STUDENT + D_OUT

    tw1_s = 0
    tw1_e = W_TEACHER * D_IN
    tb1_s = tw1_e
    tb1_e = tb1_s + W_TEACHER
    tw2_s = tb1_e
    tw2_e = tw2_s + D_OUT * W_TEACHER
    tb2_s = tw2_e
    tb2_e = tb2_s + D_OUT
    assert tb2_e == P_TEACH

    sw1_s = 0
    sw1_e = W_STUDENT * D_IN
    sb1_s = sw1_e
    sb1_e = sb1_s + W_STUDENT
    sw2_s = sb1_e
    sw2_e = sw2_s + D_OUT * W_STUDENT
    sb2_s = sw2_e
    sb2_e = sb2_s + D_OUT
    assert sb2_e == P_STUD

    # ============================================================
    # Data + teacher
    # ============================================================
    X_train = torch.randn((N_TRAIN, D_IN), device=device, dtype=DTYPE)
    X_test = torch.randn((N_TEST, D_IN), device=device, dtype=DTYPE)

    teacher_theta = (0.6 * torch.randn((P_TEACH,), device=device, dtype=DTYPE)).detach()

    teacher_W1 = teacher_theta[tw1_s:tw1_e].reshape(W_TEACHER, D_IN)
    teacher_b1 = teacher_theta[tb1_s:tb1_e]
    teacher_W2 = teacher_theta[tw2_s:tw2_e].reshape(D_OUT, W_TEACHER)
    teacher_b2 = teacher_theta[tb2_s:tb2_e]

    Y_train = torch.tanh(X_train @ teacher_W1.T + teacher_b1) @ teacher_W2.T + teacher_b2
    Y_test = torch.tanh(X_test @ teacher_W1.T + teacher_b1) @ teacher_W2.T + teacher_b2

    # ============================================================
    # Train student on train set (full θ)
    # ============================================================
    theta = (0.2 * torch.randn((P_STUD,), device=device, dtype=DTYPE)).clone().detach().requires_grad_(True)
    opt = torch.optim.AdamW([theta], lr=LR, weight_decay=WEIGHT_DECAY)

    t0 = time.time()
    for step in range(1, TRAIN_STEPS + 1):
        opt.zero_grad(set_to_none=True)

        stud_W1 = theta[sw1_s:sw1_e].reshape(W_STUDENT, D_IN)
        stud_b1 = theta[sb1_s:sb1_e]
        stud_W2 = theta[sw2_s:sw2_e].reshape(D_OUT, W_STUDENT)
        stud_b2 = theta[sb2_s:sb2_e]

        pred = torch.tanh(X_train @ stud_W1.T + stud_b1) @ stud_W2.T + stud_b2
        loss = 0.5 * (pred - Y_train).pow(2).mean()
        loss.backward()
        opt.step()

        if step == 1 or step % max(1, TRAIN_STEPS // 5) == 0:
            with torch.no_grad():
                stud_W1t = theta[sw1_s:sw1_e].reshape(W_STUDENT, D_IN)
                stud_b1t = theta[sb1_s:sb1_e]
                stud_W2t = theta[sw2_s:sw2_e].reshape(D_OUT, W_STUDENT)
                stud_b2t = theta[sb2_s:sb2_e]
                pred_t = torch.tanh(X_test @ stud_W1t.T + stud_b1t) @ stud_W2t.T + stud_b2t
                loss_t = 0.5 * (pred_t - Y_test).pow(2).mean()
            print(
                f"train step {step:5d}/{TRAIN_STEPS}  "
                f"train_loss={float(loss.detach()):.6f}  test_loss={float(loss_t):.6f}"
            )

    print(f"\nstudent training time: {time.time() - t0:.2f}s")
    theta_star = theta.detach().clone().requires_grad_(True)

    with torch.no_grad():
        stud_W1 = theta_star[sw1_s:sw1_e].reshape(W_STUDENT, D_IN)
        stud_b1 = theta_star[sb1_s:sb1_e]
        stud_W2 = theta_star[sw2_s:sw2_e].reshape(D_OUT, W_STUDENT)
        stud_b2 = theta_star[sb2_s:sb2_e]
        pred0 = torch.tanh(X_test @ stud_W1.T + stud_b1) @ stud_W2.T + stud_b2
        base_loss = float(0.5 * (pred0 - Y_test).pow(2).mean())
        base_e = (Y_test - pred0).reshape(-1)
        base_e_norm = float(base_e.norm())

    M = base_e.numel()
    print()
    print("== Held-out checkpoint stats ==")
    print(f"P_student={P_STUD}  output_dim(M)={M}  base_test_loss={base_loss:.6f}")
    print(f"||e||_2 = {base_e_norm:.6e}   (mean-squared loss uses ||e||^2/M)")
    print()

    # ============================================================
    # Jacobian J = D_θ f(θ*) on held-out outputs (flattened)
    # ============================================================
    print("computing full Jacobian J on held-out outputs ...")
    tJ = time.time()

    f0_flat = pred0.reshape(-1).detach()

    J = torch.autograd.functional.jacobian(
        lambda th: (
            torch.tanh(
                X_test @ th[sw1_s:sw1_e].reshape(W_STUDENT, D_IN).T + th[sb1_s:sb1_e]
            )
            @ th[sw2_s:sw2_e].reshape(D_OUT, W_STUDENT).T
            + th[sb2_s:sb2_e]
        ).reshape(-1),
        theta_star,
        create_graph=False,
    )
    J = J.reshape(M, P_STUD).detach()
    print(f"J shape: {tuple(J.shape)}  time={time.time() - tJ:.2f}s")

    # SVD: J = U diag(S) Vh
    print("SVD(J) ...")
    tsvd = time.time()
    U, S, Vh = torch.linalg.svd(J, full_matrices=False)
    print(f"SVD time={time.time() - tsvd:.2f}s  min(M,P)={min(M, P_STUD)}")
    print(f"top singular values: {', '.join([f'{float(x):.3e}' for x in S[: min(8, S.numel())]])}")
    print()

    e = base_e.detach()
    e_proj = U.T @ e
    e_perp_sq = float((e.norm() ** 2 - e_proj.norm() ** 2).clamp(min=0.0))

    # ============================================================
    # Choose a local radius r based on the top-k_max subspace LS solution
    # ============================================================
    k_max = max(K_LIST) if K_LIST else 0
    if k_max > 0:
        V_top_max = Vh[:k_max, :].T.contiguous()  # (P, k)
        JB_max = J @ V_top_max
        alpha_ls_max = torch.linalg.lstsq(JB_max, e).solution
        alpha_ls_max = alpha_ls_max.reshape(-1)
        delta_ls_max = V_top_max @ alpha_ls_max
        delta_ls_norm_max = float(delta_ls_max.norm())
    else:
        delta_ls_norm_max = 0.0

    r = max(RADIUS_MIN, RADIUS_MULT * delta_ls_norm_max)
    print("== Local radius ==")
    print(f"delta_ls_norm(k_max={k_max}) = {delta_ls_norm_max:.6e}")
    print(f"radius r = max({RADIUS_MIN:g}, {RADIUS_MULT:g} * delta_ls_norm) = {r:.6e}")
    print()

    # ============================================================
    # Empirical remainder / curvature scale check: estimate M2 on ||δ||=r
    #   M2(δ) ≈ 2||f(θ+δ)-f(θ)-Jδ|| / ||δ||^2
    # ============================================================
    if r > 0 and M2_SAMPLES > 0:
        print("estimating curvature proxy M2 via random directions ...")
        tM2 = time.time()
        m2_vals = []
        with torch.no_grad():
            for _ in range(M2_SAMPLES):
                v = torch.randn((P_STUD,), device=device, dtype=DTYPE)
                v = v / (v.norm() + 1e-30)
                delta = r * v

                th = theta_star + delta
                y_flat = (
                    torch.tanh(X_test @ th[sw1_s:sw1_e].reshape(W_STUDENT, D_IN).T + th[sb1_s:sb1_e])
                    @ th[sw2_s:sw2_e].reshape(D_OUT, W_STUDENT).T
                    + th[sb2_s:sb2_e]
                ).reshape(-1)
                lin = f0_flat + (J @ delta)
                rem = y_flat - lin
                m2 = float(2.0 * rem.norm() / (delta.norm() ** 2 + 1e-30))
                m2_vals.append(m2)

        m2_max = max(m2_vals) if m2_vals else 0.0
        m2_mean = float(np.mean(m2_vals)) if m2_vals else 0.0
        M2_EST = M2_SAFETY * m2_max
        print(f"M2_samples={M2_SAMPLES}  max={m2_max:.3e}  mean={m2_mean:.3e}  safety={M2_SAFETY:g}")
        print(f"set M2_EST = safety*max = {M2_EST:.3e}")
        print(f"time={time.time() - tM2:.2f}s")
    else:
        M2_EST = 0.0
    print()

    # ============================================================
    # Subspace experiments for each k:
    #   - Top-k (V from SVD(J))
    #   - Random orthonormal basis
    # Each starts from *linear* LS solution in that subspace (projected to ||α||<=r),
    # then runs nonlinear refinement under the same radius constraint.
    # ============================================================
    print("== Results (held-out) ==")
    header = (
        "k | eta(k)  | lin_pred | thm_lo | thm_hi | nonlin_top | nonlin_rand | Δ(top-lin)% | ||δ_top|| | ||δ_rand||"
    )
    print(header)
    print("-" * len(header))

    results = {
        "seed": SEED,
        "device": device.type,
        "dtype": "float64",
        "d_in": D_IN,
        "d_out": D_OUT,
        "w_teacher": W_TEACHER,
        "w_student": W_STUDENT,
        "n_train": N_TRAIN,
        "n_test": N_TEST,
        "train_steps": TRAIN_STEPS,
        "lr": LR,
        "subspace_steps": SUBSPACE_STEPS,
        "subspace_lr": SUBSPACE_LR,
        "P_student": P_STUD,
        "M_output": M,
        "base_test_loss": base_loss,
        "e_norm": base_e_norm,
        "radius_r": r,
        "M2_est": float(M2_EST),
        "k_list": K_LIST,
        "rows": [],
    }

    for k in K_LIST:
        if k == 0:
            eta_sq = float(e.norm() ** 2)
            eta = math.sqrt(max(0.0, eta_sq))
            lin_pred = 0.5 * eta_sq / M
            thm_lo = 0.5 * max(0.0, eta - 0.5 * M2_EST * r * r) ** 2 / M
            thm_hi = 0.5 * (eta + 0.5 * M2_EST * r * r) ** 2 / M
            nonlin_top = base_loss
            nonlin_rand = base_loss
            delta_top_norm = 0.0
            delta_rand_norm = 0.0
            rel_gap = 0.0
        else:
            # Top-k basis in parameter space
            V_top = Vh[:k, :].T.contiguous()  # (P, k)

            # Random orthonormal basis (P, k)
            G = torch.randn((P_STUD, k), device=device, dtype=DTYPE)
            Q, _ = torch.linalg.qr(G, mode="reduced")
            V_rand = Q

            # Linear LS solutions in each subspace
            JB_top = J @ V_top
            alpha_top = torch.linalg.lstsq(JB_top, e).solution.reshape(-1).detach()
            JB_rand = J @ V_rand
            alpha_rand = torch.linalg.lstsq(JB_rand, e).solution.reshape(-1).detach()

            # Project to ||α||<=r (since bases are orthonormal, ||δ||=||α||).
            alpha_top_norm = float(alpha_top.norm())
            alpha_rand_norm = float(alpha_rand.norm())
            if alpha_top_norm > r:
                alpha_top = alpha_top * (r / (alpha_top_norm + 1e-30))
            if alpha_rand_norm > r:
                alpha_rand = alpha_rand * (r / (alpha_rand_norm + 1e-30))

            # η(k) for the top-k pullback slice (tail in the task-singular basis).
            # With J=U diag(S) V^T (S sorted descending), the best linearized residual in the
            # top-k right-singular subspace has norm^2 = sum_{i>k} <e,u_i>^2 + ||e_perp||^2.
            tail = e_proj[k:]
            eta_sq = float((tail * tail).sum().item() + e_perp_sq)
            eta = math.sqrt(max(0.0, eta_sq))
            lin_pred = 0.5 * eta_sq / M
            thm_lo = 0.5 * max(0.0, eta - 0.5 * M2_EST * r * r) ** 2 / M
            thm_hi = 0.5 * (eta + 0.5 * M2_EST * r * r) ** 2 / M

            # Nonlinear refinement in top-k
            alpha_top = alpha_top.clone().detach().requires_grad_(True)
            opt_top = torch.optim.Adam([alpha_top], lr=SUBSPACE_LR)
            best_top = None
            best_top_alpha = None
            for _ in range(SUBSPACE_STEPS):
                opt_top.zero_grad(set_to_none=True)
                th = theta_star + V_top @ alpha_top
                y = (
                    torch.tanh(X_test @ th[sw1_s:sw1_e].reshape(W_STUDENT, D_IN).T + th[sb1_s:sb1_e])
                    @ th[sw2_s:sw2_e].reshape(D_OUT, W_STUDENT).T
                    + th[sb2_s:sb2_e]
                )
                loss_top = 0.5 * (y - Y_test).pow(2).mean()
                loss_top.backward()
                opt_top.step()
                with torch.no_grad():
                    nrm = alpha_top.norm()
                    if float(nrm) > r:
                        alpha_top.mul_(r / (float(nrm) + 1e-30))
                    cur = float(loss_top)
                    if best_top is None or cur < best_top:
                        best_top = cur
                        best_top_alpha = alpha_top.detach().clone()

            # Nonlinear refinement in random-k
            alpha_rand = alpha_rand.clone().detach().requires_grad_(True)
            opt_rand = torch.optim.Adam([alpha_rand], lr=SUBSPACE_LR)
            best_rand = None
            best_rand_alpha = None
            for _ in range(SUBSPACE_STEPS):
                opt_rand.zero_grad(set_to_none=True)
                th = theta_star + V_rand @ alpha_rand
                y = (
                    torch.tanh(X_test @ th[sw1_s:sw1_e].reshape(W_STUDENT, D_IN).T + th[sb1_s:sb1_e])
                    @ th[sw2_s:sw2_e].reshape(D_OUT, W_STUDENT).T
                    + th[sb2_s:sb2_e]
                )
                loss_rand = 0.5 * (y - Y_test).pow(2).mean()
                loss_rand.backward()
                opt_rand.step()
                with torch.no_grad():
                    nrm = alpha_rand.norm()
                    if float(nrm) > r:
                        alpha_rand.mul_(r / (float(nrm) + 1e-30))
                    cur = float(loss_rand)
                    if best_rand is None or cur < best_rand:
                        best_rand = cur
                        best_rand_alpha = alpha_rand.detach().clone()

            nonlin_top = float(best_top)
            nonlin_rand = float(best_rand)

            delta_top_norm = float((V_top @ best_top_alpha).norm()) if best_top_alpha is not None else float("nan")
            delta_rand_norm = float((V_rand @ best_rand_alpha).norm()) if best_rand_alpha is not None else float("nan")

            rel_gap = 100.0 * (nonlin_top - lin_pred) / (abs(lin_pred) + 1e-30)

        print(
            f"{k:2d} | {eta:7.3e} | {lin_pred:7.3e} | {thm_lo:7.3e} | {thm_hi:7.3e} | "
            f"{nonlin_top:10.6f} | {nonlin_rand:11.6f} | {rel_gap:10.2f} | {delta_top_norm:8.2e} | {delta_rand_norm:9.2e}"
        )

        results["rows"].append(
            {
                "k": int(k),
                "eta": float(eta),
                "lin_pred_loss": float(lin_pred),
                "thm_lo_loss": float(thm_lo),
                "thm_hi_loss": float(thm_hi),
                "nonlin_top_loss": float(nonlin_top),
                "nonlin_rand_loss": float(nonlin_rand),
                "delta_top_norm": float(delta_top_norm),
                "delta_rand_norm": float(delta_rand_norm),
                "nonlin_minus_lin_rel_percent": float(rel_gap),
            }
        )

    print()

    # ============================================================
    # Save results
    # ============================================================
    if OUT_JSON:
        os.makedirs(os.path.dirname(OUT_JSON) or ".", exist_ok=True)
        with open(OUT_JSON, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2)
        print(f"wrote: {OUT_JSON}")

    if SAVE_PLOT:
        import matplotlib.pyplot as plt

        ks = [row["k"] for row in results["rows"]]
        linp = [row["lin_pred_loss"] for row in results["rows"]]
        topn = [row["nonlin_top_loss"] for row in results["rows"]]
        randn = [row["nonlin_rand_loss"] for row in results["rows"]]
        lo = [row["thm_lo_loss"] for row in results["rows"]]
        hi = [row["thm_hi_loss"] for row in results["rows"]]

        plt.figure(figsize=(7.2, 4.8))
        plt.plot(ks, linp, "-o", label="linear pred (η tail)")
        plt.plot(ks, topn, "-o", label="nonlinear (top-k subspace)")
        plt.plot(ks, randn, "-o", label="nonlinear (random k-subspace)")
        plt.fill_between(ks, lo, hi, alpha=0.15, label="theorem band (empirical M2)")
        plt.axhline(base_loss, color="k", linestyle="--", linewidth=1, alpha=0.5, label="base loss")
        plt.xlabel("k (subspace dimension)")
        plt.ylabel("held-out loss  (0.5 * mean squared error)")
        plt.title(f"Local bridge anchor (seed={SEED}, r={r:.2e})")
        plt.grid(True, alpha=0.25)
        plt.legend(loc="best", fontsize=9)
        plt.tight_layout()

        os.makedirs(os.path.dirname(OUT_PNG) or ".", exist_ok=True)
        plt.savefig(OUT_PNG, dpi=160)
        plt.close()
        print(f"wrote: {OUT_PNG}")
