"""
GPT-2 α-crossover held-out anchor (real model; top-k vs bottom-k intervention)
=============================================================================

Implements the 1–4 protocol in a *real* pretrained LM setting:

  1) Estimate alpha_hat from support gradients:
        log |c_i|^2 vs log lambda_i slope  -> alpha_hat
  2) Predict:
        alpha_hat < 1/2 => top-k wins
        alpha_hat > 1/2 => bottom-k wins
  3) Held-out verify:
        fine-tune with updates constrained to top-k vs bottom-k eigensubspace
  4) Report prediction accuracy and one-sided binomial p-value vs chance(0.5).

Notes:
  - Metric is empirical Fisher on a "base" domain: M ≈ (1/n) Σ g_i g_i^T, using
    per-sample gradients of the next-token loss w.r.t. one target parameter tensor.
  - Eigensystem is computed via the dual trick on CPU: K=(1/n) G G^T.
  - Intervention updates only a single parameter tensor (default: GPT-2 block 11 c_attn weight).
"""

from __future__ import annotations

import argparse
import copy
import json
import math
import random
import time

import numpy as np
import torch


def collect_grads(model, tokenizer, param, texts, device, max_len):
    grads = []
    for text in texts:
        toks = tokenizer(text, return_tensors="pt", max_length=max_len, truncation=True, padding=False).to(device)
        if toks["input_ids"].shape[1] < 2:
            continue
        model.zero_grad(set_to_none=True)
        out = model(**toks, labels=toks["input_ids"])
        out.loss.backward()
        grads.append(param.grad.detach().flatten().cpu().clone())
    return torch.stack(grads, dim=0) if grads else None


def evaluate_loss(model, tokenizer, texts, device, max_len, max_eval):
    model.eval()
    losses = []
    with torch.no_grad():
        for text in texts[:max_eval]:
            toks = tokenizer(text, return_tensors="pt", max_length=max_len, truncation=True, padding=False).to(device)
            if toks["input_ids"].shape[1] < 2:
                continue
            out = model(**toks, labels=toks["input_ids"])
            losses.append(float(out.loss.item()))
    model.train()
    return float(np.mean(losses)) if losses else float("inf")


def subspace_finetune(model, tokenizer, param_name, texts_train, texts_eval, V_sub, device, max_len, steps, lr, eval_every, max_eval):
    model_ft = copy.deepcopy(model)
    for n, p in model_ft.named_parameters():
        p.requires_grad_(n == param_name)
    param = dict(model_ft.named_parameters())[param_name]
    orig_shape = param.shape
    P = param.numel()
    if V_sub.shape[0] != P:
        raise ValueError("V_sub has wrong first dim")
    V_dev = V_sub.to(device)

    eval_curve = []
    init_loss = evaluate_loss(model_ft, tokenizer, texts_eval, device, max_len, max_eval)
    eval_curve.append((0, init_loss))

    for step in range(1, steps + 1):
        model_ft.zero_grad(set_to_none=True)

        # Accumulate gradient over a small batch of texts for stability.
        batch_loss = 0.0
        n_valid = 0
        for _ in range(4):
            text = random.choice(texts_train)
            toks = tokenizer(text, return_tensors="pt", max_length=max_len, truncation=True, padding=False).to(device)
            if toks["input_ids"].shape[1] < 2:
                continue
            out = model_ft(**toks, labels=toks["input_ids"])
            (out.loss / 4.0).backward()
            batch_loss += float(out.loss.item())
            n_valid += 1
        if n_valid == 0:
            continue

        with torch.no_grad():
            g = param.grad.flatten()
            coeff = V_dev.T @ g
            g_proj = V_dev @ coeff
            param.data -= lr * g_proj.view(orig_shape)

        if step % eval_every == 0 or step == steps:
            ev = evaluate_loss(model_ft, tokenizer, texts_eval, device, max_len, max_eval)
            eval_curve.append((step, ev))

    return eval_curve


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--seeds", type=str, default="0,1,2")
    parser.add_argument("--device", type=str, default="auto", choices=["auto", "cpu", "cuda", "mps"])
    parser.add_argument("--model", type=str, default="gpt2")

    parser.add_argument("--param_name", type=str, default="transformer.h.11.attn.c_attn.weight")
    parser.add_argument("--max_len", type=int, default=64)

    parser.add_argument("--metric_mode", type=str, default="task", choices=["task", "base"])
    parser.add_argument("--metric_n", type=int, default=30)
    parser.add_argument("--task_n", type=int, default=50)
    parser.add_argument("--alpha_n", type=int, default=20)
    parser.add_argument("--eval_n", type=int, default=10)
    parser.add_argument("--train_frac", type=float, default=0.8)

    parser.add_argument("--min_eig_ratio", type=float, default=1e-6)
    parser.add_argument("--fit_frac", type=float, default=0.8, help="Use leading fraction of points for slope fit.")
    parser.add_argument("--neutral_band", type=float, default=0.05)
    parser.add_argument("--min_r2", type=float, default=0.2)

    parser.add_argument("--k", type=int, default=16)
    parser.add_argument("--steps", type=int, default=80)
    parser.add_argument("--lr", type=float, default=5e-3)
    parser.add_argument("--eval_every", type=int, default=20)

    parser.add_argument("--out_json", type=str, default="")
    args = parser.parse_args()

    if args.device == "auto":
        if torch.cuda.is_available():
            device = torch.device("cuda")
        elif torch.backends.mps.is_available():
            device = torch.device("mps")
        else:
            device = torch.device("cpu")
    else:
        device = torch.device(args.device)

    # ------------------------------------------------------------
    # Text generators (templates; no external dataset dependency).
    # ------------------------------------------------------------
    def gen_english(n):
        s = [
            "The history of mathematics can be seen as an ever-increasing series of abstractions.",
            "Machine learning provides systems with the ability to learn and improve from experience.",
            "Quantum computing leverages superposition and entanglement to process information.",
            "Statistical mechanics relates microscopic properties to macroscopic behavior.",
            "Neuroscience studies how the brain processes information and adapts through learning.",
            "The periodic table organizes chemical elements by atomic number and recurring properties.",
            "Thermodynamics deals with heat, work, temperature, and the transformation of energy.",
            "The Renaissance was a period of cultural rebirth that began in Italy and spread across Europe.",
            "Cryptography enables secure communication in the presence of adversarial behavior.",
            "Natural language processing enables computers to understand and generate human language.",
            "General relativity describes gravity as curvature of spacetime caused by mass and energy.",
            "In economics, supply and demand determine prices in competitive markets.",
            "Genetics explains how traits pass from parents to offspring through DNA sequences.",
            "Climate change refers to long-term shifts in temperatures driven by human activities.",
            "Urbanization is the process of population shift from rural areas to cities and towns.",
        ]
        out = []
        for _ in range(n):
            out.append(random.choice(s))
        return out

    def gen_code(n):
        s = [
            "def fibonacci(n):\n    if n <= 1: return n\n    return fibonacci(n-1) + fibonacci(n-2)\nprint([fibonacci(i) for i in range(10)])",
            "import numpy as np\nA = np.random.randn(5,5)\nw, v = np.linalg.eigh(A @ A.T)\nprint(w[::-1])",
            "class DataLoader:\n    def __init__(self, data, bs=32):\n        self.data = data\n        self.bs = bs\n    def __iter__(self):\n        for i in range(0, len(self.data), self.bs):\n            yield self.data[i:i+self.bs]",
            "def quicksort(arr):\n    if len(arr) <= 1: return arr\n    p = arr[len(arr)//2]\n    return quicksort([x for x in arr if x<p]) + [x for x in arr if x==p] + quicksort([x for x in arr if x>p])",
            "try:\n    result = complex_operation(x)\nexcept ValueError as e:\n    logger.error(f\"failed: {e}\")\n    result = None",
            "async def fetch(url):\n    async with aiohttp.ClientSession() as s:\n        async with s.get(url) as r:\n            return await r.json()",
        ]
        out = []
        for _ in range(n):
            out.append(random.choice(s))
        return out

    def gen_korean(n):
        s = [
            "한국어 자연어처리는 형태소 분석과 어절 분리가 중요한 과제이다.",
            "기후변화는 전 세계적으로 가장 심각한 환경 문제 중 하나로 인식되고 있다.",
            "인공지능 기술의 발전은 사회 전반에 큰 변화를 가져오고 있다.",
            "서울은 대한민국의 수도이자 경제 문화의 중심지로 인구 밀도가 매우 높다.",
            "재생에너지 기술의 발전과 보급은 탄소 중립 목표 달성에 중요하다.",
            "한국의 반도체 산업은 글로벌 시장에서 핵심적인 위치를 차지하고 있다.",
        ]
        out = []
        for _ in range(n):
            out.append(random.choice(s))
        return out

    def gen_json(n):
        keys = ["model", "lr", "batch", "epochs", "hidden", "layers", "dropout", "decay", "optim", "sched", "act", "maxlen", "vocab", "heads", "embed"]
        out = []
        for _ in range(n):
            random.shuffle(keys)
            nk = random.randint(4, 7)
            pairs = []
            for k in keys[:nk]:
                if k in ("lr", "decay", "dropout"):
                    v = f"{random.uniform(1e-4, 0.1):.5f}"
                elif k in ("batch", "hidden", "layers", "heads", "epochs", "maxlen", "vocab", "embed"):
                    v = str(random.choice([8, 16, 32, 64, 128, 256, 512, 768, 1024]))
                else:
                    v = '"' + random.choice(["adam", "sgd", "adamw", "gelu", "relu", "tf"]) + '"'
                pairs.append(f'\"{k}\":{v}')
            out.append("{" + ",".join(pairs) + "}")
        return out

    domains = {
        "Code": gen_code,
        "Korean": gen_korean,
        "JSON": gen_json,
    }

    seed_list = [int(x.strip()) for x in args.seeds.split(",") if x.strip()]
    all_rows = []
    n_total = 0
    n_correct = 0

    t_all = time.time()
    for seed in seed_list:
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)

        try:
            from transformers import GPT2LMHeadModel, GPT2Tokenizer
        except Exception as e:
            raise RuntimeError("transformers is required for this script") from e

        model = GPT2LMHeadModel.from_pretrained(args.model).to(device)
        tokenizer = GPT2Tokenizer.from_pretrained(args.model)
        tokenizer.pad_token = tokenizer.eos_token
        model.train()

        named = dict(model.named_parameters())
        if args.param_name not in named:
            raise ValueError(f"param_name not found: {args.param_name}")
        param = named[args.param_name]

        if args.metric_mode == "base":
            english = gen_english(args.metric_n)
            G_metric = collect_grads(model, tokenizer, param, english, device, args.max_len)
            if G_metric is None or G_metric.shape[0] < 10:
                raise RuntimeError("Failed to collect base(metric) gradients")

            n_metric = int(G_metric.shape[0])
            K = (G_metric @ G_metric.T) / float(n_metric)  # CPU tensor
            eigvals, eigvecs = torch.linalg.eigh(K)
            order = torch.argsort(eigvals, descending=True)
            eigvals = eigvals[order]
            eigvecs = eigvecs[:, order]

            pos = eigvals > (eigvals[0] * float(args.min_eig_ratio) + 1e-12)
            eigvals = eigvals[pos]
            eigvecs = eigvecs[:, pos]
            r = int(eigvals.numel())
            if r < max(12, 2 * args.k):
                raise RuntimeError(f"Too few eigenvalues: r={r}")

            sigmas = torch.sqrt(float(n_metric) * eigvals.clamp(min=1e-12))
            V_shared = (G_metric.T @ eigvecs) / sigmas.unsqueeze(0)  # (P, r) on CPU
            V_shared, _ = torch.linalg.qr(V_shared)  # orthonormalize
            r_shared = r
            eigvals_shared = eigvals
            print(f"\n[seed={seed}] metric_mode=base metric_n={n_metric} eig_rank={r_shared} device={device}")
        else:
            V_shared = None
            r_shared = None
            eigvals_shared = None
            print(f"\n[seed={seed}] metric_mode=task device={device}")

        for domain_name, gen in domains.items():
            texts = gen(args.task_n)
            random.shuffle(texts)

            n_metric = min(args.metric_n, len(texts))
            if n_metric < max(8, 2 * args.k):
                continue
            texts_metric = texts[:n_metric]
            rest0 = texts[n_metric:]

            n_alpha = min(args.alpha_n, len(rest0))
            if n_alpha < 5:
                continue
            texts_alpha = rest0[:n_alpha]
            rest = rest0[n_alpha:]
            n_train = max(1, int(args.train_frac * len(rest)))
            texts_train = rest[:n_train]
            texts_eval = rest[n_train:]
            if not texts_eval:
                texts_eval = rest[-min(len(rest), args.eval_n) :]

            if args.metric_mode == "task":
                G_metric = collect_grads(model, tokenizer, param, texts_metric, device, args.max_len)
                if G_metric is None or G_metric.shape[0] < 10:
                    continue

                n_metric_eff = int(G_metric.shape[0])
                K = (G_metric @ G_metric.T) / float(n_metric_eff)
                eigvals, eigvecs = torch.linalg.eigh(K)
                order = torch.argsort(eigvals, descending=True)
                eigvals = eigvals[order]
                eigvecs = eigvecs[:, order]

                pos = eigvals > (eigvals[0] * float(args.min_eig_ratio) + 1e-12)
                eigvals = eigvals[pos]
                eigvecs = eigvecs[:, pos]
                r = int(eigvals.numel())
                if r < max(12, 2 * args.k):
                    continue

                sigmas = torch.sqrt(float(n_metric_eff) * eigvals.clamp(min=1e-12))
                V = (G_metric.T @ eigvecs) / sigmas.unsqueeze(0)
                V, _ = torch.linalg.qr(V)
            else:
                V = V_shared
                eigvals = eigvals_shared
                r = r_shared

            k = int(min(args.k, int(r) // 2))
            V_top = V[:, :k].contiguous()
            V_bot = V[:, -k:].contiguous()

            G_alpha = collect_grads(model, tokenizer, param, texts_alpha, device, args.max_len)
            if G_alpha is None or G_alpha.shape[0] < 5:
                continue
            g_alpha = G_alpha.mean(dim=0)  # CPU
            proj = V.T @ g_alpha
            c2 = (proj**2) / (eigvals + 1e-12)

            lam_np = eigvals.numpy()
            c2_np = c2.numpy()
            mask = (lam_np > 1e-12) & (c2_np > 1e-30)
            if int(mask.sum()) < 10:
                continue

            x = np.log(lam_np[mask])
            ylog = np.log(c2_np[mask])
            n_use = max(10, int(float(args.fit_frac) * len(x)))
            slope, intercept = np.polyfit(x[:n_use], ylog[:n_use], 1)
            alpha_hat = float((1.0 - slope) / 2.0)

            y_pred = slope * x[:n_use] + intercept
            ss_res = float(np.sum((ylog[:n_use] - y_pred) ** 2))
            ss_tot = float(np.sum((ylog[:n_use] - float(np.mean(ylog[:n_use]))) ** 2))
            r2 = 1.0 - ss_res / (ss_tot + 1e-12)

            predicted = "top-k" if alpha_hat < 0.5 else "bottom-k"
            if abs(alpha_hat - 0.5) <= float(args.neutral_band) or r2 < float(args.min_r2):
                predicted = "neutral"

            init_loss = evaluate_loss(model, tokenizer, texts_eval, device, args.max_len, args.eval_n)
            curve_top = subspace_finetune(
                model,
                tokenizer,
                args.param_name,
                texts_train,
                texts_eval,
                V_top,
                device,
                args.max_len,
                args.steps,
                args.lr,
                args.eval_every,
                args.eval_n,
            )
            curve_bot = subspace_finetune(
                model,
                tokenizer,
                args.param_name,
                texts_train,
                texts_eval,
                V_bot,
                device,
                args.max_len,
                args.steps,
                args.lr,
                args.eval_every,
                args.eval_n,
            )

            final_top = float(curve_top[-1][1])
            final_bot = float(curve_bot[-1][1])
            actual = "top-k" if final_top < final_bot else "bottom-k"

            scored = predicted in ("top-k", "bottom-k")
            if scored:
                n_total += 1
                n_correct += int(predicted == actual)

            row = {
                "seed": seed,
                "domain": domain_name,
                "metric_mode": args.metric_mode,
                "alpha_hat": alpha_hat,
                "slope": float(slope),
                "r2": r2,
                "predicted": predicted,
                "actual": actual,
                "init_loss": init_loss,
                "final_top": final_top,
                "final_bot": final_bot,
                "delta_top": final_top - init_loss,
                "delta_bot": final_bot - init_loss,
                "k": k,
                "eig_rank": r,
                "n_metric": int(n_metric),
                "n_alpha": int(G_alpha.shape[0]),
                "n_train": len(texts_train),
                "n_eval": min(len(texts_eval), args.eval_n),
            }
            all_rows.append(row)

            print(
                f"  [{domain_name}] alpha_hat={alpha_hat:+.3f} r2={r2:.2f} pred={predicted:8s} "
                f"init={init_loss:.4f} top={final_top:.4f} bot={final_bot:.4f} actual={actual}"
            )

    if n_total:
        tail = 0.0
        for i in range(n_correct, n_total + 1):
            tail += math.comb(n_total, i) * (0.5**i) * (0.5 ** (n_total - i))
        pval = min(max(tail, 0.0), 1.0)
        acc = n_correct / n_total
    else:
        pval = float("nan")
        acc = float("nan")

    print("\n" + "=" * 72)
    print("GPT-2 α-CROSSOVER HELD-OUT SUMMARY")
    print("=" * 72)
    print(f"scored_tasks: {n_total}/{len(all_rows)}")
    print(f"prediction_accuracy: {n_correct}/{n_total} = {acc:.3f}")
    if n_total:
        print(f"binomial_pvalue(one-sided, >0.5): {pval:.3g}")
    print(f"elapsed: {time.time()-t_all:.1f}s")

    if args.out_json:
        out = {
            "args": vars(args),
            "device": str(device),
            "rows": all_rows,
            "scored_tasks": n_total,
            "n_correct": n_correct,
            "accuracy": acc,
            "p_value_gt_chance": pval,
        }
        with open(args.out_json, "w", encoding="utf-8") as f:
            json.dump(out, f, indent=2, ensure_ascii=False)
        print(f"wrote: {args.out_json}")


if __name__ == "__main__":
    main()
