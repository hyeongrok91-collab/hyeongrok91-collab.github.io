"""
GPT-2 Subspace Intervention v3: Leakage-Free + Tier-3 Causative Test
=====================================================================
v2 문제 (GPT Pro 검증):
  1. train/eval LEAKAGE: 전체 target으로 subspace 선택 후 같은 eval 평가
  2. "std LoRA" 라벨 오류: 실제로는 projected gradient subspace
  3. Tier 3 causative 불충분: α predict-then-verify 없음

v3 수정:
  1. 3-way split: support (subspace 선택) / train (fine-tune) / eval (평가)
  2. 라벨 수정: "Fisher top-k" / "|c²|-guided" / "Random"
  3. Tier 3 추가: support에서 α̂ 추정 → 어떤 selector가 이길지 예측 → eval 검증
  4. Fisher basis 내 random subset 대조군 추가
"""

import torch
import torch.nn.functional as F
import numpy as np
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import random
import copy
import warnings
warnings.filterwarnings('ignore')

device = 'mps' if torch.backends.mps.is_available() else 'cpu'
print(f"Device: {device}")

TARGET_LAYER = 'transformer.h.11.attn.c_attn.weight'

# ============================================================
# Data generators (larger pool for 3-way split)
# ============================================================
def gen_english(n=80):
    s = [
        "The history of mathematics can be seen as an ever-increasing series of abstractions.",
        "Machine learning provides systems with the ability to learn and improve from experience.",
        "Quantum computing leverages superposition and entanglement to process information.",
        "Statistical mechanics relates microscopic atomic properties to macroscopic bulk properties.",
        "The periodic table organizes elements by atomic number and electron configuration.",
        "Neural networks are computing systems inspired by biological brain architecture.",
        "Thermodynamics deals with heat, work, temperature, and their relation to energy.",
        "The Renaissance sparked new interest in classical Greek and Roman art and literature.",
        "Cryptography enables secure communication in the presence of adversarial behavior.",
        "Photosynthesis converts light energy into chemical energy for plant growth.",
        "Plate tectonics describes the motion of large plates of Earth's lithosphere.",
        "The Enlightenment dominated European intellectual thought in the 18th century.",
        "Cognitive psychology studies attention, memory, language use, and problem solving.",
        "Climate change involves long-term shifts in temperatures driven by human activity.",
        "Conservation biology studies preservation and restoration of natural environments.",
        "Urbanization is the population shift from rural areas to cities and towns.",
        "Genetics reveals how traits pass from parents to offspring through DNA sequences.",
        "Robotics combines engineering and computer science to design intelligent machines.",
        "Natural language processing enables computers to understand human language.",
        "General relativity describes gravity as curvature of spacetime caused by mass.",
        "The development of writing systems was a key achievement in human civilization.",
        "Molecular biology studies the molecular basis of biological activity in cells.",
        "Supply and demand determines the equilibrium price in competitive markets.",
        "Archaeological discoveries reshape understanding of ancient civilizations.",
        "The global economy is interconnected through trade and technology exchange.",
        "Biodiversity encompasses genetic, species, and ecosystem diversity on Earth.",
        "The philosophy of science examines foundations and methods of scientific inquiry.",
        "The human genome project mapped all genes providing valuable medical information.",
        "Artificial intelligence research has seen rapid growth due to deep learning advances.",
        "Democratic governance relies on the principle of consent of the governed population.",
    ]
    random.shuffle(s)
    return s[:n]

def gen_code(n=80):
    s = [
        "def fibonacci(n):\n    if n <= 1: return n\n    return fibonacci(n-1) + fibonacci(n-2)\nprint([fibonacci(i) for i in range(15)])",
        "class DataLoader:\n    def __init__(self, data, bs=32):\n        self.data, self.bs = data, bs\n    def __iter__(self):\n        for i in range(0, len(self.data), self.bs):\n            yield self.data[i:i+self.bs]",
        "import numpy as np\ndef eigensolve(A):\n    vals, vecs = np.linalg.eigh(A)\n    return vals[::-1], vecs[:, ::-1]",
        "def quicksort(arr):\n    if len(arr) <= 1: return arr\n    p = arr[len(arr)//2]\n    return quicksort([x for x in arr if x<p]) + [x for x in arr if x==p] + quicksort([x for x in arr if x>p])",
        "@dataclass\nclass Config:\n    lr: float = 1e-3\n    batch_size: int = 32\n    epochs: int = 100\n    hidden: int = 512",
        "import torch.nn as nn\nclass MLP(nn.Module):\n    def __init__(self, d_in, d_h, d_out):\n        super().__init__()\n        self.net = nn.Sequential(nn.Linear(d_in,d_h), nn.ReLU(), nn.Linear(d_h,d_out))\n    def forward(self, x): return self.net(x)",
        "from collections import Counter\ndef top_words(text, k=10):\n    return Counter(text.lower().split()).most_common(k)",
        "def binary_search(arr, target):\n    lo, hi = 0, len(arr)-1\n    while lo <= hi:\n        mid = (lo+hi)//2\n        if arr[mid] == target: return mid\n        elif arr[mid] < target: lo = mid+1\n        else: hi = mid-1\n    return -1",
        "class LRUCache:\n    def __init__(self, cap):\n        self.cache = OrderedDict()\n        self.cap = cap\n    def get(self, key):\n        if key in self.cache:\n            self.cache.move_to_end(key)\n            return self.cache[key]\n        return -1",
        "def merge_sort(arr):\n    if len(arr) <= 1: return arr\n    mid = len(arr)//2\n    return merge(merge_sort(arr[:mid]), merge_sort(arr[mid:]))",
        "import pandas as pd\ndf = pd.read_csv('data.csv')\ndf['ratio'] = df['val'] / df['total']\nprint(df.groupby('cat').agg({'ratio': ['mean', 'std']}))",
        "class Graph:\n    def __init__(self): self.adj = defaultdict(list)\n    def add(self, u, v): self.adj[u].append(v)\n    def bfs(self, s):\n        vis, q = {s}, deque([s])\n        while q:\n            for nb in self.adj[q.popleft()]:\n                if nb not in vis: vis.add(nb); q.append(nb)",
        "async def fetch(url):\n    async with aiohttp.ClientSession() as s:\n        async with s.get(url) as r:\n            return await r.json()",
        "def matrix_mul(A, B):\n    n, m, k = len(A), len(B[0]), len(B)\n    return [[sum(A[i][l]*B[l][j] for l in range(k)) for j in range(m)] for i in range(n)]",
        "def retry(n=3, delay=1):\n    def dec(f):\n        @wraps(f)\n        def w(*a,**k):\n            for i in range(n):\n                try: return f(*a,**k)\n                except: sleep(delay)\n            raise RuntimeError\n        return w\n    return dec",
    ]
    random.shuffle(s)
    return s[:n]

def gen_korean(n=40):
    s = [
        "인공지능의 발전은 현대 사회의 모든 분야에 걸쳐 근본적인 변화를 가져오고 있다.",
        "대한민국의 반도체 산업은 글로벌 시장에서 핵심적인 위치를 차지하고 있다.",
        "양자컴퓨팅 기술은 기존 컴퓨터로는 풀기 어려운 복잡한 문제들을 해결할 수 있다.",
        "한국어 자연어처리 연구는 최근 몇 년간 급격한 발전을 이루었다.",
        "기후변화는 전 세계적으로 가장 심각한 환경 문제 중 하나로 인식되고 있다.",
        "디지털 전환은 기업의 비즈니스 모델과 운영 방식을 변화시키고 있다.",
        "생명공학 기술의 발전은 의약품 개발에 혁명적인 변화를 가져오고 있다.",
        "빅데이터 분석은 대용량의 데이터에서 유의미한 패턴을 추출하는 기술이다.",
        "한국의 영화 산업은 세계적인 주목을 받으며 한류 문화를 이끌고 있다.",
        "블록체인 기술은 거래의 투명성과 보안성을 보장하는 분산원장 기술이다.",
        "서울은 대한민국의 수도이자 경제 문화의 중심지이다.",
        "한국의 교통 인프라는 고속철도와 지하철을 중심으로 구축되어 있다.",
        "재생에너지 기술의 보급은 탄소 중립 목표 달성의 핵심 과제이다.",
        "한국의 스타트업 생태계는 핀테크 분야에서 혁신적인 기업들이 등장하고 있다.",
        "조선시대의 과학 기술은 세계적 수준이었으며 다양한 기기가 발명되었다.",
        "한국 경제는 수출 주도형 성장 모델을 기반으로 발전해왔다.",
        "사물인터넷 기술은 일상 기기들을 연결하여 자동화와 효율성을 높이고 있다.",
        "로봇 공학의 발전은 제조업과 서비스 산업 모두에서 혁신을 가져오고 있다.",
        "한국의 우주 산업은 누리호 발사 성공으로 새로운 전환점을 맞이하였다.",
        "한국의 음식 문화는 발효식품을 중심으로 세계적 인정을 받고 있다.",
    ]
    random.shuffle(s)
    return s[:n]

def gen_json(n=80):
    s = []
    keys = ["model", "lr", "batch", "epochs", "hidden", "layers", "dropout",
            "decay", "optim", "sched", "act", "maxlen", "vocab", "heads", "embed"]
    for i in range(n):
        random.shuffle(keys)
        nk = random.randint(4, 7)
        pairs = []
        for k in keys[:nk]:
            if k in ("lr", "decay", "dropout"):
                v = f"{random.uniform(1e-4,0.1):.5f}"
            elif k in ("batch", "hidden", "layers", "heads", "epochs", "maxlen", "vocab", "embed"):
                v = str(random.choice([8,16,32,64,128,256,512,768,1024]))
            else:
                v = f'"{random.choice(["adam","sgd","adamw","gelu","relu","tf"])}"'
            pairs.append(f'"{k}":{v}')
        s.append("{" + ",".join(pairs) + "}")
    return s[:n]

# Additional domain for more diversity
def gen_math(n=40):
    s = [
        "Let f: R^n -> R be a twice differentiable convex function with Lipschitz gradient.",
        "The spectral theorem states that any symmetric matrix has an orthonormal eigenbasis.",
        "Consider the optimization problem min_x ||Ax - b||^2 subject to ||x|| <= 1.",
        "A Hilbert space is a complete inner product space generalizing Euclidean geometry.",
        "The singular value decomposition factorizes A = U Sigma V^T for any matrix A.",
        "Gradient descent converges at rate O(1/t) for convex functions with bounded gradients.",
        "The Hessian matrix captures second-order curvature information at a critical point.",
        "A manifold is a topological space locally homeomorphic to Euclidean space.",
        "The divergence theorem relates surface integrals to volume integrals in R^3.",
        "Stochastic gradient descent uses random mini-batches to estimate the full gradient.",
        "The Riemannian metric tensor defines inner products on tangent spaces smoothly.",
        "Banach fixed point theorem guarantees unique fixed points for contraction mappings.",
        "The Fourier transform decomposes a signal into constituent frequency components.",
        "Lagrange multipliers find extrema of functions subject to equality constraints.",
        "The central limit theorem shows that sample means converge to normal distribution.",
        "A reproducing kernel Hilbert space is defined by its reproducing kernel function.",
        "The implicit function theorem gives conditions for solving F(x,y)=0 for y=g(x).",
        "Positive definite matrices have all positive eigenvalues and Cholesky decomposition.",
        "The Jacobian matrix represents the best linear approximation of a vector function.",
        "Measure theory provides the foundation for modern probability and integration.",
    ]
    random.shuffle(s)
    return s[:n]

# ============================================================
# Core functions
# ============================================================
def setup():
    print("Loading GPT-2...")
    model = GPT2LMHeadModel.from_pretrained('gpt2').to(device)
    tok = GPT2Tokenizer.from_pretrained('gpt2')
    tok.pad_token = tok.eos_token
    model.eval()
    return model, tok

def get_param(model):
    for n, p in model.named_parameters():
        if n == TARGET_LAYER: return p
    return None

def collect_grads(model, texts, param, tok, max_len=64):
    grads = []
    for t in texts:
        toks = tok(t, return_tensors='pt', max_length=max_len, truncation=True).to(device)
        if toks['input_ids'].shape[1] < 2: continue
        model.zero_grad()
        out = model(**toks, labels=toks['input_ids'])
        out.loss.backward()
        grads.append(param.grad.flatten().detach().cpu().clone())
    return torch.stack(grads) if grads else None

def compute_eigensystem(G_base):
    """Compute Fisher eigensystem from base domain gradients ONLY."""
    n = G_base.shape[0]
    K = (G_base @ G_base.T) / n
    eigvals, eigvecs = torch.linalg.eigh(K)
    idx = torch.argsort(eigvals, descending=True)
    eigvals = eigvals[idx]
    eigvecs = eigvecs[:, idx]
    pos = eigvals > eigvals[0] * 1e-6
    eigvals = eigvals[pos]
    eigvecs = eigvecs[:, pos]
    
    sigmas = torch.sqrt(n * eigvals.clamp(min=1e-12))
    V = (G_base.T @ eigvecs) / sigmas.unsqueeze(0)
    
    return eigvals, V

def compute_c_squared(V, G_support):
    """
    Compute |c_i|² from SUPPORT set gradients only (no leakage).
    c_i = projection of mean support gradient onto Fisher basis direction.
    """
    g_support_mean = G_support.mean(dim=0)
    proj = V.T @ g_support_mean
    return proj**2

def estimate_alpha(eigvals, c_sq, k_fit=None):
    """
    Estimate α from log|c_i|² vs log λ_i regression.
    
    Under SC(α,g): |c_i|² = λ_i^{1-2α} |ĝ_i|²
    If |ĝ_i| roughly comparable: log|c_i|² ≈ (1-2α) log λ_i + const
    Slope β̂ = 1-2α → α̂ = (1-β̂)/2
    """
    n_eig = len(eigvals)
    if k_fit is None:
        k_fit = min(n_eig, 20)  # use top eigenvalues for fit
    
    log_lam = torch.log(eigvals[:k_fit].clamp(min=1e-15)).numpy()
    log_csq = torch.log(c_sq[:k_fit].clamp(min=1e-15)).numpy()
    
    # Linear regression
    valid = np.isfinite(log_lam) & np.isfinite(log_csq)
    if valid.sum() < 3:
        return 0.0, 0.0  # not enough data
    
    log_lam = log_lam[valid]
    log_csq = log_csq[valid]
    
    beta_hat = np.polyfit(log_lam, log_csq, 1)[0]
    alpha_hat = (1 - beta_hat) / 2
    
    # R² for confidence
    ss_res = np.sum((log_csq - np.polyval(np.polyfit(log_lam, log_csq, 1), log_lam))**2)
    ss_tot = np.sum((log_csq - log_csq.mean())**2)
    r_squared = 1 - ss_res / (ss_tot + 1e-12)
    
    return alpha_hat, r_squared

def predict_selector(alpha_hat):
    """
    Predict which selector should win based on α̂.
    
    α < 0.5: top-k should win (high eigenvalues carry signal)
    α > 0.5: bottom-k / |c²|-guided should win (low eigenvalues carry signal)
    """
    if alpha_hat < 0.4:
        return 'topk', f"α̂={alpha_hat:.3f} < 0.5 → top-k predicted"
    elif alpha_hat > 0.6:
        return 'guided', f"α̂={alpha_hat:.3f} > 0.5 → |c²|-guided predicted"
    else:
        return 'uncertain', f"α̂={alpha_hat:.3f} ≈ 0.5 → uncertain crossover zone"

def evaluate(model, tok, texts, max_n=None):
    """Evaluate on held-out texts."""
    model.eval()
    if max_n is None:
        max_n = len(texts)
    losses = []
    with torch.no_grad():
        for t in texts[:max_n]:
            toks_d = tok(t, return_tensors='pt', max_length=64, truncation=True).to(device)
            if toks_d['input_ids'].shape[1] < 2: continue
            out = model(**toks_d, labels=toks_d['input_ids'])
            losses.append(out.loss.item())
    return np.mean(losses) if losses else float('inf')

def subspace_finetune(model, tok, texts_train, texts_eval, V_sub, n_steps=100, lr=1e-2):
    """
    Constrained fine-tuning in subspace V_sub (P × k).
    Train on texts_train, evaluate on texts_eval (strictly disjoint).
    """
    model_ft = copy.deepcopy(model)
    param = get_param(model_ft)
    P = param.numel()
    orig_shape = param.shape
    
    for n, p in model_ft.named_parameters():
        p.requires_grad_(n == TARGET_LAYER)
    
    V_dev = V_sub.to(device)
    
    losses = []
    
    # Initial eval
    init_loss = evaluate(model_ft, tok, texts_eval)
    losses.append((0, init_loss))
    
    for step in range(1, n_steps + 1):
        model_ft.zero_grad()
        n_valid = 0
        
        for _ in range(4):
            idx = random.randint(0, len(texts_train) - 1)
            toks_d = tok(texts_train[idx], return_tensors='pt', max_length=64, truncation=True).to(device)
            if toks_d['input_ids'].shape[1] < 2: continue
            out = model_ft(**toks_d, labels=toks_d['input_ids'])
            (out.loss / 4).backward()
            n_valid += 1
        
        if n_valid == 0: continue
        
        with torch.no_grad():
            g = param.grad.flatten()
            coeffs = V_dev.T @ g
            g_proj = V_dev @ coeffs
            param.data -= lr * g_proj.view(orig_shape)
        
        if step % 10 == 0 or step == 1:
            el = evaluate(model_ft, tok, texts_eval)
            losses.append((step, el))
    
    return losses

# ============================================================
# Main experiment
# ============================================================
def run():
    random.seed(42)
    torch.manual_seed(42)
    np.random.seed(42)
    
    model, tok = setup()
    param = get_param(model)
    P = param.numel()
    print(f"Target: {TARGET_LAYER} ({P:,} params)")
    
    # Base domain: English
    english = gen_english(40)
    
    # Target domains with 3-way split
    domains = {
        'Code':   gen_code(15),
        'Korean': gen_korean(18),
        'JSON':   gen_json(20),
        'Math':   gen_math(18),
    }
    
    print("\n[1] Base eigensystem (English)...")
    G_base = collect_grads(model, english, param, tok)
    print(f"    G_base: {G_base.shape}")
    eigvals, V = compute_eigensystem(G_base)
    n_eig = len(eigvals)
    print(f"    Eigenvalues: {n_eig}")
    
    K = 10  # subspace dimension
    N_STEPS = 100
    N_SEEDS = 5
    
    # Calibrate LR
    print("\n[2] Calibrating learning rate...")
    model.zero_grad()
    toks_d = tok(english[0], return_tensors='pt', max_length=64, truncation=True).to(device)
    out = model(**toks_d, labels=toks_d['input_ids'])
    out.loss.backward()
    full_grad_norm = param.grad.flatten().norm().item()
    param_norm = param.data.flatten().norm().item()
    target_step = 0.001 * param_norm
    LR = max(min(target_step / (full_grad_norm + 1e-12), 1.0), 1e-3)
    print(f"    Calibrated LR: {LR:.4f}")
    
    all_results = {}
    tier3_predictions = {}
    
    for domain_name, texts in domains.items():
        print(f"\n{'='*60}")
        print(f"Domain: {domain_name} ({len(texts)} texts)")
        print(f"{'='*60}")
        
        # ============================================================
        # 3-WAY SPLIT: support / train / eval (NO LEAKAGE)
        # ============================================================
        n_total = len(texts)
        n_support = max(3, n_total // 3)   # ~1/3 for subspace selection
        n_eval = max(3, n_total // 3)       # ~1/3 for evaluation
        n_train = n_total - n_support - n_eval  # rest for fine-tuning
        
        # Shuffle deterministically per domain
        rng = random.Random(hash(domain_name))
        shuffled = list(texts)
        rng.shuffle(shuffled)
        
        texts_support = shuffled[:n_support]
        texts_train = shuffled[n_support:n_support + n_train]
        texts_eval = shuffled[n_support + n_train:]
        
        print(f"  Split: support={len(texts_support)}, train={len(texts_train)}, eval={len(texts_eval)}")
        
        # ============================================================
        # STEP A: Compute |c_i|² from SUPPORT set only (leakage-free)
        # ============================================================
        G_support = collect_grads(model, texts_support, param, tok)
        if G_support is None:
            print(f"  SKIP: no valid gradients from support set")
            continue
        
        c_sq = compute_c_squared(V, G_support)
        
        k = min(K, n_eig // 2)
        print(f"  Using k={k} dimensions")
        
        # ============================================================
        # STEP B: TIER 3 — Estimate α and predict winner
        # ============================================================
        alpha_hat, r_sq = estimate_alpha(eigvals, c_sq)
        predicted_winner, prediction_msg = predict_selector(alpha_hat)
        print(f"\n  [TIER 3] α estimation:")
        print(f"    α̂ = {alpha_hat:.3f} (R² = {r_sq:.3f})")
        print(f"    Prediction: {prediction_msg}")
        
        tier3_predictions[domain_name] = {
            'alpha_hat': alpha_hat,
            'r_squared': r_sq,
            'predicted': predicted_winner,
            'message': prediction_msg,
        }
        
        # ============================================================
        # STEP C: Define subspaces
        # ============================================================
        # (A) Fisher top-k (base domain eigenvalues)
        V_topk = V[:, :k].clone()
        
        # (B) |c²|-guided (from support set — no leakage)
        c_sq_np = c_sq.numpy()
        opt_idx = np.argsort(c_sq_np)[::-1][:k].copy()
        V_guided = V[:, opt_idx].clone()
        
        # (C) Random WITHIN Fisher basis (stronger control)
        n_available = min(n_eig, max(k * 3, 30))
        rand_idx = np.random.choice(n_available, k, replace=False)
        V_fisher_rand = V[:, rand_idx].clone()
        
        # (D) Random in ambient space (weakest control)
        V_ambient_rand = torch.randn(P, k)
        V_ambient_rand, _ = torch.linalg.qr(V_ambient_rand)
        
        overlap = len(set(range(k)) & set(opt_idx.tolist()))
        print(f"\n  Subspaces:")
        print(f"    Top-k:      indices {list(range(k))}")
        print(f"    |c²|-guided: indices {sorted(opt_idx.tolist())}")
        print(f"    Overlap:    {overlap}/{k}")
        
        c_sq_sorted = np.sort(c_sq_np)[::-1]
        topk_energy = c_sq_np[:k].sum() / (c_sq_np.sum() + 1e-12) * 100
        guided_energy = c_sq_np[opt_idx].sum() / (c_sq_np.sum() + 1e-12) * 100
        print(f"    Top-k energy:     {topk_energy:.1f}%")
        print(f"    |c²|-guided energy: {guided_energy:.1f}%")
        
        # ============================================================
        # STEP D: Fine-tune in each subspace, evaluate on HELD-OUT eval
        # ============================================================
        domain_results = {
            'topk': [], 'guided': [],
            'fisher_rand': [], 'ambient_rand': []
        }
        
        for seed in range(N_SEEDS):
            random.seed(seed * 7 + 13)
            torch.manual_seed(seed * 7 + 13)
            
            print(f"\n  Seed {seed}:")
            
            # (A) Fisher top-k
            res_A = subspace_finetune(model, tok, texts_train, texts_eval, V_topk, N_STEPS, LR)
            l0, lf = res_A[0][1], res_A[-1][1]
            print(f"    (A) Fisher top-k:    {l0:.4f} → {lf:.4f} (Δ={l0-lf:.4f})")
            domain_results['topk'].append(res_A)
            
            # (B) |c²|-guided
            res_B = subspace_finetune(model, tok, texts_train, texts_eval, V_guided, N_STEPS, LR)
            l0, lf = res_B[0][1], res_B[-1][1]
            print(f"    (B) |c²|-guided:     {l0:.4f} → {lf:.4f} (Δ={l0-lf:.4f})")
            domain_results['guided'].append(res_B)
            
            # (C) Random within Fisher basis
            res_C = subspace_finetune(model, tok, texts_train, texts_eval, V_fisher_rand, N_STEPS, LR)
            l0, lf = res_C[0][1], res_C[-1][1]
            print(f"    (C) Fisher-random:   {l0:.4f} → {lf:.4f} (Δ={l0-lf:.4f})")
            domain_results['fisher_rand'].append(res_C)
            
            # (D) Ambient random
            res_D = subspace_finetune(model, tok, texts_train, texts_eval, V_ambient_rand, N_STEPS, LR)
            l0, lf = res_D[0][1], res_D[-1][1]
            print(f"    (D) Ambient random:  {l0:.4f} → {lf:.4f} (Δ={l0-lf:.4f})")
            domain_results['ambient_rand'].append(res_D)
        
        all_results[domain_name] = domain_results
    
    # ============================================================
    # Summary
    # ============================================================
    print("\n" + "=" * 70)
    print("INTERVENTION SUMMARY (v3: leakage-free)")
    print("=" * 70)
    
    tier3_correct = 0
    tier3_total = 0
    
    for domain, res in all_results.items():
        finals = {}
        for key in ['topk', 'guided', 'fisher_rand', 'ambient_rand']:
            finals[key] = [r[-1][1] for r in res[key]]
        
        means = {k: np.mean(v) for k, v in finals.items()}
        stds = {k: np.std(v) for k, v in finals.items()}
        
        guided_beats_topk = sum(1 for a, b in zip(finals['topk'], finals['guided']) if b < a)
        topk_beats_fisher_rand = sum(1 for a, c in zip(finals['topk'], finals['fisher_rand']) if a < c)
        
        print(f"\n  {domain}:")
        print(f"    Fisher top-k:     {means['topk']:.4f} ± {stds['topk']:.4f}")
        print(f"    |c²|-guided:      {means['guided']:.4f} ± {stds['guided']:.4f}")
        print(f"    Fisher-random:    {means['fisher_rand']:.4f} ± {stds['fisher_rand']:.4f}")
        print(f"    Ambient-random:   {means['ambient_rand']:.4f} ± {stds['ambient_rand']:.4f}")
        print(f"    Guided beat Top-k: {guided_beats_topk}/{N_SEEDS}")
        
        # Determine actual winner
        if means['guided'] < means['topk']:
            actual_winner = 'guided'
            print(f"    → ✅ |c²|-guided WINS ({(means['topk']-means['guided'])/means['topk']*100:.1f}% better)")
        else:
            actual_winner = 'topk'
            print(f"    → Fisher top-k wins ({(means['guided']-means['topk'])/means['guided']*100:.1f}%)")
        
        # TIER 3: Check prediction
        if domain in tier3_predictions:
            pred = tier3_predictions[domain]
            predicted = pred['predicted']
            
            if predicted == 'uncertain':
                print(f"    [TIER 3] α̂={pred['alpha_hat']:.3f} → uncertain (crossover zone)")
            else:
                is_correct = (predicted == actual_winner)
                tier3_total += 1
                if is_correct:
                    tier3_correct += 1
                emoji = "✅" if is_correct else "❌"
                print(f"    [TIER 3] Predicted: {predicted}, Actual: {actual_winner} → {emoji}")
    
    # TIER 3 summary
    print(f"\n{'='*70}")
    print(f"TIER 3 CAUSATIVE TEST: {tier3_correct}/{tier3_total} predictions correct")
    if tier3_total > 0:
        acc = tier3_correct / tier3_total * 100
        print(f"  Accuracy: {acc:.0f}%")
        if acc >= 75:
            print(f"  → ✅ Theory predicts real behavior (>75% accuracy)")
        elif acc >= 50:
            print(f"  → ⚠️ Above chance but not decisive")
        else:
            print(f"  → ❌ Below chance — theory falsified?")
    print(f"{'='*70}")
    
    # ============================================================
    # Plot
    # ============================================================
    n_dom = len(all_results)
    fig, axes = plt.subplots(1, n_dom, figsize=(5*n_dom, 5))
    if n_dom == 1: axes = [axes]
    
    colors = {
        'topk': '#2196F3',
        'guided': '#F44336',
        'fisher_rand': '#4CAF50',
        'ambient_rand': '#9E9E9E',
    }
    labels = {
        'topk': 'Fisher top-k',
        'guided': '|c²|-guided (support)',
        'fisher_rand': 'Fisher-random',
        'ambient_rand': 'Ambient-random',
    }
    styles = {
        'topk': '-',
        'guided': '-',
        'fisher_rand': '--',
        'ambient_rand': ':',
    }
    
    for ax, (domain, res) in zip(axes, all_results.items()):
        for key in ['topk', 'guided', 'fisher_rand', 'ambient_rand']:
            step_data = {}
            for curve in res[key]:
                for step, loss in curve:
                    step_data.setdefault(step, []).append(loss)
            
            steps = sorted(step_data.keys())
            ms = [np.mean(step_data[s]) for s in steps]
            ss = [np.std(step_data[s]) for s in steps]
            
            ax.plot(steps, ms, color=colors[key], linestyle=styles[key],
                    linewidth=2, label=labels[key])
            ax.fill_between(steps, [m-s for m,s in zip(ms,ss)],
                          [m+s for m,s in zip(ms,ss)], alpha=0.12, color=colors[key])
        
        # Add α prediction to title
        if domain in tier3_predictions:
            pred = tier3_predictions[domain]
            ax.set_title(f'{domain} (α̂={pred["alpha_hat"]:.2f})')
        else:
            ax.set_title(domain)
        ax.set_xlabel('Step')
        ax.set_ylabel('Held-out Loss')
        ax.legend(fontsize=6)
        ax.grid(True, alpha=0.3)
    
    plt.suptitle('GPT-2 Subspace Intervention v3\n(Leakage-free 3-way split + α prediction)',
                 fontsize=11, fontweight='bold')
    plt.tight_layout()
    
    save_path = '/Users/hyeongrok/Documents/UAF, 기하- 대수적 프레임 워크/uaf math/polytope_research/paper_c/gpt2_intervention_v3.png'
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"\nPlot saved: {save_path}")

if __name__ == '__main__':
    run()
