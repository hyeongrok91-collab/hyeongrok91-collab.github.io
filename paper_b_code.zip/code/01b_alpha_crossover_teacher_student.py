"""
Teacher-student α-crossover anchor (Digits + MLP; held-out)
==========================================================

Purpose:
  Produce a *supportive* (causal, controlled) version of the 1–4 protocol where
  the source condition SC(α,g) is satisfied by construction, but the model is a
  real nonlinear network and the input distribution is real data (digits).

Construction:
  - Pick a base checkpoint θ0 (random init by default).
  - On a support set X_metric, compute J(θ0) and M = J^T J.
  - Sample α_true and a "roughly uniform" g_hat, and define a teacher update
        δ_teacher = W * (λ^{-α_true} ⊙ g_hat)   (W = eigenvectors of M).
    Scale δ_teacher to a small norm so we remain in the local regime.
  - Teacher parameters: θT = θ0 + δ_teacher. Targets are y = f(θT)(x).

Protocol:
  1) α̂ estimate from held-out gradient on X_alpha:
       slope(log ĉ_i^2 vs log λ_i) -> α̂
  2) Predict top/bottom by α̂ < 1/2 or > 1/2
  3) Solve best δ in top-k vs bottom-k subspace (LS on X_adapt)
  4) Evaluate held-out MSE on X_test. If prediction accuracy > chance -> supports theory.
"""

from __future__ import annotations

import argparse
import json
import math
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.datasets import load_digits


class TinyMLP(nn.Module):
    def __init__(self, input_dim: int, hidden: int):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, hidden)
        self.fc2 = nn.Linear(hidden, hidden)
        self.fc3 = nn.Linear(hidden, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x).squeeze(-1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--device", type=str, default="auto", choices=["auto", "cpu", "cuda", "mps"])
    parser.add_argument("--hidden", type=int, default=32)

    parser.add_argument("--trials", type=int, default=50)
    parser.add_argument("--k", type=int, default=8)

    parser.add_argument("--n_metric", type=int, default=80)
    parser.add_argument("--n_alpha", type=int, default=80)
    parser.add_argument("--n_adapt", type=int, default=80)
    parser.add_argument("--n_test", type=int, default=80)

    parser.add_argument("--alpha_lo", type=float, default=-0.2)
    parser.add_argument("--alpha_hi", type=float, default=1.2)
    parser.add_argument("--neutral_gap", type=float, default=0.05, help="Resample α_true if |α_true-0.5| < gap.")

    parser.add_argument("--teacher_delta_frac", type=float, default=0.02, help="||δ_teacher|| as fraction of ||θ0||.")
    parser.add_argument("--adapt_delta_frac", type=float, default=0.05, help="Max ||δ_adapt|| as fraction of ||θ0||.")

    parser.add_argument("--out_json", type=str, default="")
    args = parser.parse_args()

    if args.device == "auto":
        if torch.cuda.is_available():
            device = torch.device("cuda")
        elif torch.backends.mps.is_available():
            device = torch.device("mps")
        else:
            device = torch.device("cpu")
    else:
        device = torch.device(args.device)

    rng = np.random.default_rng(args.seed)
    torch.manual_seed(args.seed)

    digits = load_digits()
    X_all = torch.tensor(digits.data, dtype=torch.float32)
    X_all = (X_all - X_all.mean()) / (X_all.std() + 1e-8)

    model0 = TinyMLP(input_dim=X_all.shape[1], hidden=args.hidden).to(device)
    theta0_vec = torch.nn.utils.parameters_to_vector(model0.parameters()).detach()
    theta0_norm = float(torch.norm(theta0_vec).item())
    teacher_delta_norm = max(1e-12, float(args.teacher_delta_frac) * theta0_norm)
    adapt_delta_norm = max(1e-12, float(args.adapt_delta_frac) * theta0_norm)

    print(f"device={device}  P={theta0_vec.numel()}  ||θ0||={theta0_norm:.3e}")
    print(f"||δ_teacher||={teacher_delta_norm:.3e}  max||δ_adapt||={adapt_delta_norm:.3e}")

    t0 = time.time()
    n_scored = 0
    n_correct = 0
    rows = []

    for trial in range(args.trials):
        idx = rng.permutation(len(X_all))
        if args.n_metric + args.n_alpha + args.n_adapt + args.n_test > len(idx):
            raise ValueError("Requested split sizes exceed dataset size")

        i0 = 0
        X_metric = X_all[idx[i0 : i0 + args.n_metric]].to(device)
        i0 += args.n_metric
        X_alpha = X_all[idx[i0 : i0 + args.n_alpha]].to(device)
        i0 += args.n_alpha
        X_adapt = X_all[idx[i0 : i0 + args.n_adapt]].to(device)
        i0 += args.n_adapt
        X_test = X_all[idx[i0 : i0 + args.n_test]].to(device)

        # --------------------------------------------------------
        # Metric eigensystem from J_metric (CPU linalg).
        # --------------------------------------------------------
        model = TinyMLP(input_dim=X_all.shape[1], hidden=args.hidden).to(device)
        model.load_state_dict(model0.state_dict(), strict=True)
        model.train(False)
        params = list(model.parameters())

        jac_rows_cpu = []
        for i in range(args.n_metric):
            f_i = model(X_metric[i : i + 1]).squeeze(0)
            grads = torch.autograd.grad(f_i, params, retain_graph=False, create_graph=False)
            jac_i = torch.cat([g.reshape(-1) for g in grads]).detach().cpu()
            jac_rows_cpu.append(jac_i)

        Jm_cpu = torch.stack(jac_rows_cpu, dim=0)
        K_cpu = (Jm_cpu @ Jm_cpu.T) / float(args.n_metric)
        eigvals_cpu, eigvecs_cpu = torch.linalg.eigh(K_cpu)
        order = torch.argsort(eigvals_cpu, descending=True)
        eigvals_cpu = eigvals_cpu[order]
        eigvecs_cpu = eigvecs_cpu[:, order]

        tol = float(eigvals_cpu[0].abs().item()) * 1e-6 + 1e-12
        pos = eigvals_cpu > tol
        eigvals_cpu = eigvals_cpu[pos]
        eigvecs_cpu = eigvecs_cpu[:, pos]
        r = int(eigvals_cpu.numel())
        if r < max(10, 2 * args.k):
            continue

        sigmas = torch.sqrt(float(args.n_metric) * eigvals_cpu.clamp(min=1e-12))
        W_cpu = (Jm_cpu.T @ eigvecs_cpu) / sigmas.unsqueeze(0)  # (P, r)
        W_cpu, _ = torch.linalg.qr(W_cpu)
        lam_cpu = eigvals_cpu.clamp(min=1e-12)

        # --------------------------------------------------------
        # Sample alpha_true away from 0.5 and build teacher δ.
        # --------------------------------------------------------
        alpha_true = float(rng.uniform(args.alpha_lo, args.alpha_hi))
        while abs(alpha_true - 0.5) < args.neutral_gap:
            alpha_true = float(rng.uniform(args.alpha_lo, args.alpha_hi))

        g_hat = torch.randn(r)
        g_hat = g_hat.abs() + 0.2  # enforce "comparable magnitude"
        g_hat = g_hat / g_hat.norm()

        coeff = lam_cpu.pow(-alpha_true) * g_hat
        delta_teacher_cpu = W_cpu @ coeff
        dn = float(torch.norm(delta_teacher_cpu).item())
        if dn > 0:
            delta_teacher_cpu = delta_teacher_cpu * (teacher_delta_norm / dn)

        # Teacher model: θT = θ0 + δ_teacher.
        model_teacher = TinyMLP(input_dim=X_all.shape[1], hidden=args.hidden).to(device)
        model_teacher.load_state_dict(model0.state_dict(), strict=True)
        params_T = list(model_teacher.parameters())
        with torch.no_grad():
            vec = torch.nn.utils.parameters_to_vector(params_T)
            vec = vec + delta_teacher_cpu.to(device)
            torch.nn.utils.vector_to_parameters(vec, params_T)

        with torch.no_grad():
            y_alpha = model_teacher(X_alpha).detach()
            y_adapt = model_teacher(X_adapt).detach()
            y_test = model_teacher(X_test).detach()

        # --------------------------------------------------------
        # α̂ estimation from gradient on alpha set at θ0.
        # --------------------------------------------------------
        pred_alpha = model(X_alpha)
        loss_alpha = 0.5 * torch.mean((pred_alpha - y_alpha) ** 2)
        grads_alpha = torch.autograd.grad(loss_alpha, params, retain_graph=False, create_graph=False)
        g_alpha_cpu = torch.cat([g.reshape(-1) for g in grads_alpha]).detach().cpu()

        proj = W_cpu.T @ g_alpha_cpu
        c2_hat = (proj**2) / (lam_cpu + 1e-12)

        lam_np = lam_cpu.numpy()
        c2_np = c2_hat.numpy()
        mask = (lam_np > 1e-10) & (c2_np > 1e-20)
        if int(mask.sum()) < 10:
            continue

        x = np.log(lam_np[mask])
        ylog = np.log(c2_np[mask])
        slope_hat, intercept_hat = np.polyfit(x, ylog, 1)
        alpha_hat = float((1.0 - slope_hat) / 2.0)

        y_pred = slope_hat * x + intercept_hat
        ss_res = float(np.sum((ylog - y_pred) ** 2))
        ss_tot = float(np.sum((ylog - float(np.mean(ylog))) ** 2))
        r2 = 1.0 - ss_res / (ss_tot + 1e-12)

        predicted = "top-k" if alpha_hat < 0.5 else "bottom-k"

        # --------------------------------------------------------
        # LS solve in top/bottom subspace on adapt set.
        # --------------------------------------------------------
        k = int(min(args.k, r // 2))
        basis_top = W_cpu[:, :k].to(device).contiguous()
        basis_bot = W_cpu[:, -k:].to(device).contiguous()

        with torch.no_grad():
            f_adapt = model(X_adapt)
        e_adapt = (y_adapt - f_adapt).detach()

        jac_adapt_cpu = []
        for i in range(args.n_adapt):
            f_i = model(X_adapt[i : i + 1]).squeeze(0)
            grads = torch.autograd.grad(f_i, params, retain_graph=False, create_graph=False)
            jac_i = torch.cat([g.reshape(-1) for g in grads]).detach().cpu()
            jac_adapt_cpu.append(jac_i)
        Ja_cpu = torch.stack(jac_adapt_cpu, dim=0)

        def solve_delta(basis: torch.Tensor) -> tuple[torch.Tensor, float]:
            basis_cpu = basis.detach().cpu()
            Z_cpu = Ja_cpu @ basis_cpu
            a = torch.linalg.lstsq(Z_cpu, e_adapt.detach().cpu()).solution
            delta_cpu = basis_cpu @ a
            dn2 = float(torch.norm(delta_cpu).item())
            if dn2 > adapt_delta_norm:
                delta_cpu = delta_cpu * (adapt_delta_norm / dn2)
                dn2 = adapt_delta_norm
            return delta_cpu.to(device), dn2

        delta_top, dn_top = solve_delta(basis_top)
        delta_bot, dn_bot = solve_delta(basis_bot)

        method = {}
        for name, delta in [("top-k", delta_top), ("bottom-k", delta_bot)]:
            model_ft = TinyMLP(input_dim=X_all.shape[1], hidden=args.hidden).to(device)
            model_ft.load_state_dict(model0.state_dict(), strict=True)
            params_ft = list(model_ft.parameters())
            with torch.no_grad():
                vec = torch.nn.utils.parameters_to_vector(params_ft)
                vec = vec + delta
                torch.nn.utils.vector_to_parameters(vec, params_ft)
                pred_test = model_ft(X_test)
                mse = (0.5 * torch.mean((pred_test - y_test) ** 2)).item()
            method[name] = float(mse)

        actual = "top-k" if method["top-k"] < method["bottom-k"] else "bottom-k"
        ok = (predicted == actual)

        n_correct += int(ok)
        n_scored += 1

        if (trial + 1) % max(1, args.trials // 10) == 0 or trial < 3:
            print(
                f"[{trial+1:3d}/{args.trials}] "
                f"alpha_true={alpha_true:+.3f} alpha_hat={alpha_hat:+.3f} r2={r2:.2f} "
                f"pred={predicted:8s} actual={actual:8s} "
                f"mse_top={method['top-k']:.3e} mse_bot={method['bottom-k']:.3e} "
                f"{'OK' if ok else 'NO'}"
            )

        rows.append(
            {
                "trial": trial,
                "alpha_true": alpha_true,
                "alpha_hat": alpha_hat,
                "slope_hat": float(slope_hat),
                "r2": r2,
                "predicted": predicted,
                "actual": actual,
                "mse_top": method["top-k"],
                "mse_bottom": method["bottom-k"],
                "delta_top_norm": dn_top,
                "delta_bottom_norm": dn_bot,
                "rank": r,
            }
        )

    acc = (n_correct / n_scored) if n_scored else float("nan")
    if n_scored:
        tail = 0.0
        for i in range(n_correct, n_scored + 1):
            tail += math.comb(n_scored, i) * (0.5**i) * (0.5 ** (n_scored - i))
        pval = min(max(tail, 0.0), 1.0)
    else:
        pval = float("nan")

    print("\n" + "=" * 72)
    print("TEACHER-STUDENT α-CROSSOVER SUMMARY")
    print("=" * 72)
    print(f"scored_trials: {n_scored}/{args.trials}")
    print(f"prediction_accuracy: {n_correct}/{n_scored} = {acc:.3f}")
    if n_scored:
        print(f"binomial_pvalue(one-sided, >0.5): {pval:.3g}")
    print(f"elapsed: {time.time()-t0:.1f}s")

    if args.out_json:
        out = {
            "args": vars(args),
            "device": str(device),
            "theta0_norm": theta0_norm,
            "teacher_delta_norm": teacher_delta_norm,
            "adapt_delta_norm": adapt_delta_norm,
            "scored_trials": n_scored,
            "n_correct": n_correct,
            "accuracy": acc,
            "p_value_gt_chance": pval,
            "rows": rows,
        }
        with open(args.out_json, "w", encoding="utf-8") as f:
            json.dump(out, f, indent=2, ensure_ascii=False)
        print(f"wrote: {args.out_json}")


if __name__ == "__main__":
    main()

