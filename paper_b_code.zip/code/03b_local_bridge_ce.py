#!/usr/bin/env python3
"""
CE-version gold anchor: local Fisher pullback + subspace intervention.

What this does
  - Teacher produces soft labels p*(y|x) (full support).
  - Student tanh-MLP is trained with *soft-target cross-entropy*.
  - At a held-out checkpoint θ*:
      - compute logits Jacobian J = D_θ z(θ*) (z = logits on held-out set)
      - compute per-sample CE Hessian on logits H_i = diag(p_i) - p_i p_i^T
      - build the Fisher-weighted Jacobian B = G^{1/2} J (block-diagonal G from H_i / N)
      - form the function-space Newton target e = -G^+ ∇_z L (implemented per-sample via H_i^+)
      - compute η(k) tail in the task-singular basis of B
      - compare:
          (i) quadratic-model prediction (2nd order Taylor / Gauss-Newton) vs
         (ii) actual CE optimization in the top-k pullback subspace vs a random k-subspace

This addresses the "G_T != I" concern for cross-entropy (LLM-like) tasks.
"""

import json
import math
import os
import time

import numpy as np
import torch


if __name__ == "__main__":
    # ============================================================
    # Config (env-overridable)
    # ============================================================
    SEED = int(os.getenv("SEED", "0"))

    DEVICE = os.getenv("DEVICE", "cpu").strip().lower()
    if DEVICE == "auto":
        if torch.cuda.is_available():
            DEVICE = "cuda"
        elif getattr(torch.backends, "mps", None) is not None and torch.backends.mps.is_available():
            DEVICE = "mps"
        else:
            DEVICE = "cpu"

    DTYPE = torch.float64

    D_IN = int(os.getenv("D_IN", "16"))
    N_CLASSES = int(os.getenv("N_CLASSES", "10"))
    W_TEACHER = int(os.getenv("W_TEACHER", "64"))
    W_STUDENT = int(os.getenv("W_STUDENT", "32"))
    TEACHER_TEMP = float(os.getenv("TEACHER_TEMP", "2.0"))

    N_TRAIN = int(os.getenv("N_TRAIN", "768"))
    N_TEST = int(os.getenv("N_TEST", "256"))

    TRAIN_STEPS = int(os.getenv("TRAIN_STEPS", "1200"))
    LR = float(os.getenv("LR", "2e-2"))
    WEIGHT_DECAY = float(os.getenv("WEIGHT_DECAY", "0.0"))

    SUBSPACE_STEPS = int(os.getenv("SUBSPACE_STEPS", "250"))
    SUBSPACE_LR = float(os.getenv("SUBSPACE_LR", "8e-2"))

    RADIUS_MULT = float(os.getenv("RADIUS_MULT", "1.5"))
    RADIUS_MIN = float(os.getenv("RADIUS_MIN", "1e-6"))

    PINV_TOL = float(os.getenv("PINV_TOL", "1e-12"))

    K_LIST_RAW = os.getenv("K_LIST", "0,1,2,4,8,16,32,64")
    K_LIST = [int(x) for x in K_LIST_RAW.split(",") if x.strip()]
    K_LIST = sorted(set(K_LIST))

    SAVE_PLOT = int(os.getenv("SAVE_PLOT", "1"))
    OUT_JSON = os.getenv("OUT_JSON", f"sweep_outputs/local_bridge_anchor_ce_seed{SEED}.json").strip()
    OUT_PNG = os.getenv("OUT_PNG", f"figures/local_bridge_anchor_ce_seed{SEED}.png").strip()

    torch.manual_seed(SEED)
    np.random.seed(SEED)

    device = torch.device(DEVICE)
    print("=" * 78)
    print("GOLD ANCHOR (CE): Fisher pullback + top-k vs random subspace")
    print("=" * 78)
    print(f"seed={SEED} device={device.type} dtype=float64")
    print(f"d_in={D_IN} classes={N_CLASSES} w_teacher={W_TEACHER} w_student={W_STUDENT} teacher_temp={TEACHER_TEMP:g}")
    print(f"train={N_TRAIN} test={N_TEST} train_steps={TRAIN_STEPS} lr={LR:g}")
    print(f"subspace_steps={SUBSPACE_STEPS} subspace_lr={SUBSPACE_LR:g}")
    print(f"K_LIST={K_LIST}")
    print()

    # ============================================================
    # Parameter layout: θ = [W1, b1, W2, b2]
    #   W1: (w, d_in)   b1: (w,)
    #   W2: (C, w)      b2: (C,)
    # ============================================================
    P_TEACH = W_TEACHER * D_IN + W_TEACHER + N_CLASSES * W_TEACHER + N_CLASSES
    P_STUD = W_STUDENT * D_IN + W_STUDENT + N_CLASSES * W_STUDENT + N_CLASSES

    tw1_s = 0
    tw1_e = W_TEACHER * D_IN
    tb1_s = tw1_e
    tb1_e = tb1_s + W_TEACHER
    tw2_s = tb1_e
    tw2_e = tw2_s + N_CLASSES * W_TEACHER
    tb2_s = tw2_e
    tb2_e = tb2_s + N_CLASSES
    assert tb2_e == P_TEACH

    sw1_s = 0
    sw1_e = W_STUDENT * D_IN
    sb1_s = sw1_e
    sb1_e = sb1_s + W_STUDENT
    sw2_s = sb1_e
    sw2_e = sw2_s + N_CLASSES * W_STUDENT
    sb2_s = sw2_e
    sb2_e = sb2_s + N_CLASSES
    assert sb2_e == P_STUD

    # ============================================================
    # Data + teacher soft labels
    # ============================================================
    X_train = torch.randn((N_TRAIN, D_IN), device=device, dtype=DTYPE)
    X_test = torch.randn((N_TEST, D_IN), device=device, dtype=DTYPE)

    teacher_theta = (0.6 * torch.randn((P_TEACH,), device=device, dtype=DTYPE)).detach()
    teacher_W1 = teacher_theta[tw1_s:tw1_e].reshape(W_TEACHER, D_IN)
    teacher_b1 = teacher_theta[tb1_s:tb1_e]
    teacher_W2 = teacher_theta[tw2_s:tw2_e].reshape(N_CLASSES, W_TEACHER)
    teacher_b2 = teacher_theta[tb2_s:tb2_e]

    with torch.no_grad():
        logits_train_t = torch.tanh(X_train @ teacher_W1.T + teacher_b1) @ teacher_W2.T + teacher_b2
        logits_test_t = torch.tanh(X_test @ teacher_W1.T + teacher_b1) @ teacher_W2.T + teacher_b2
        p_train = torch.softmax(logits_train_t / TEACHER_TEMP, dim=-1)
        p_test = torch.softmax(logits_test_t / TEACHER_TEMP, dim=-1)

    # ============================================================
    # Train student with soft-target CE
    # ============================================================
    theta = (0.2 * torch.randn((P_STUD,), device=device, dtype=DTYPE)).clone().detach().requires_grad_(True)
    opt = torch.optim.AdamW([theta], lr=LR, weight_decay=WEIGHT_DECAY)

    t0 = time.time()
    for step in range(1, TRAIN_STEPS + 1):
        opt.zero_grad(set_to_none=True)

        stud_W1 = theta[sw1_s:sw1_e].reshape(W_STUDENT, D_IN)
        stud_b1 = theta[sb1_s:sb1_e]
        stud_W2 = theta[sw2_s:sw2_e].reshape(N_CLASSES, W_STUDENT)
        stud_b2 = theta[sb2_s:sb2_e]

        logits = torch.tanh(X_train @ stud_W1.T + stud_b1) @ stud_W2.T + stud_b2
        logp = torch.log_softmax(logits, dim=-1)
        loss = -(p_train * logp).sum(dim=-1).mean()
        loss.backward()
        opt.step()

        if step == 1 or step % max(1, TRAIN_STEPS // 5) == 0:
            with torch.no_grad():
                stud_W1t = theta[sw1_s:sw1_e].reshape(W_STUDENT, D_IN)
                stud_b1t = theta[sb1_s:sb1_e]
                stud_W2t = theta[sw2_s:sw2_e].reshape(N_CLASSES, W_STUDENT)
                stud_b2t = theta[sb2_s:sb2_e]
                logits_t = torch.tanh(X_test @ stud_W1t.T + stud_b1t) @ stud_W2t.T + stud_b2t
                loss_t = -(p_test * torch.log_softmax(logits_t, dim=-1)).sum(dim=-1).mean()
            print(
                f"train step {step:5d}/{TRAIN_STEPS}  "
                f"train_ce={float(loss.detach()):.6f}  test_ce={float(loss_t):.6f}"
            )

    print(f"\nstudent training time: {time.time() - t0:.2f}s")
    theta_star = theta.detach().clone().requires_grad_(True)

    # ============================================================
    # Held-out baseline, gradient on logits, and per-sample Fisher blocks
    # ============================================================
    with torch.no_grad():
        stud_W1 = theta_star[sw1_s:sw1_e].reshape(W_STUDENT, D_IN)
        stud_b1 = theta_star[sb1_s:sb1_e]
        stud_W2 = theta_star[sw2_s:sw2_e].reshape(N_CLASSES, W_STUDENT)
        stud_b2 = theta_star[sb2_s:sb2_e]
        logits0 = torch.tanh(X_test @ stud_W1.T + stud_b1) @ stud_W2.T + stud_b2  # (N, C)
        logp0 = torch.log_softmax(logits0, dim=-1)
        base_loss = float(-(p_test * logp0).sum(dim=-1).mean())
        p0 = torch.softmax(logits0, dim=-1)

        # g_z = ∂L/∂logits, shape (N, C)
        g_z = (p0 - p_test) / float(N_TEST)

    print()
    print("== Held-out checkpoint stats ==")
    print(f"P_student={P_STUD}  N_test={N_TEST}  classes={N_CLASSES}  base_test_CE={base_loss:.6f}")
    print()

    # ============================================================
    # Full Jacobian J = D_θ logits(θ*) on held-out set
    # Shape: (N*C, P)
    # ============================================================
    print("computing full Jacobian J on held-out logits ...")
    tJ = time.time()
    J = torch.autograd.functional.jacobian(
        lambda th: (
            torch.tanh(X_test @ th[sw1_s:sw1_e].reshape(W_STUDENT, D_IN).T + th[sb1_s:sb1_e])
            @ th[sw2_s:sw2_e].reshape(N_CLASSES, W_STUDENT).T
            + th[sb2_s:sb2_e]
        ).reshape(-1),
        theta_star,
        create_graph=False,
    )
    J = J.reshape(N_TEST * N_CLASSES, P_STUD).detach()
    print(f"J shape: {tuple(J.shape)}  time={time.time() - tJ:.2f}s")

    # ============================================================
    # Build Fisher-weighted B = G^{1/2} J and e_w = G^{1/2} e
    #   G = blockdiag(H_i)/N, H_i = diag(p_i) - p_i p_i^T
    #   e_i = -H_i^+ (p_i - p*_i)  (note: N cancels with the 1/N in g_z)
    # ============================================================
    print("building Fisher-weighted Jacobian B and Newton target e ...")
    tB = time.time()
    J_blocks = J.reshape(N_TEST, N_CLASSES, P_STUD).contiguous()

    B_blocks = []
    e_w_blocks = []
    e_w_norm_sq = 0.0

    with torch.no_grad():
        inv_sqrt_N = 1.0 / math.sqrt(float(N_TEST))
        for i in range(N_TEST):
            p_i = p0[i]  # (C,)
            y_i = p_test[i]  # (C,)

            H = torch.diag(p_i) - torch.outer(p_i, p_i)  # (C,C)
            evals, evecs = torch.linalg.eigh(H)
            evals_clamped = evals.clamp(min=0.0)

            sqrt_evals = torch.sqrt(evals_clamped)
            sqrtH = (evecs * sqrt_evals) @ evecs.T

            inv_evals = torch.zeros_like(evals)
            mask = evals_clamped > PINV_TOL
            inv_evals[mask] = 1.0 / evals_clamped[mask]
            H_pinv = (evecs * inv_evals) @ evecs.T

            gcore = (p_i - y_i)  # (C,)
            e_i = -(H_pinv @ gcore)  # (C,)

            # Weighting by sqrt(G) = sqrt(H/N) = sqrtH / sqrt(N)
            B_i = (sqrtH @ J_blocks[i]) * inv_sqrt_N  # (C,P)
            ewi = (sqrtH @ e_i) * inv_sqrt_N  # (C,)

            B_blocks.append(B_i)
            e_w_blocks.append(ewi)
            e_w_norm_sq += float((ewi * ewi).sum().item())

    B = torch.cat(B_blocks, dim=0).detach()  # (N*C, P)
    e_w = torch.cat(e_w_blocks, dim=0).detach()  # (N*C,)
    print(f"B shape: {tuple(B.shape)}  ||e_w||^2={e_w_norm_sq:.6e}  time={time.time() - tB:.2f}s")
    print()

    # ============================================================
    # SVD in the Fisher-weighted geometry
    # ============================================================
    print("SVD(B) ...")
    tsvd = time.time()
    U, S, Vh = torch.linalg.svd(B, full_matrices=False)
    print(f"SVD time={time.time() - tsvd:.2f}s  min(M,P)={min(B.shape[0], B.shape[1])}")
    print(f"top singular values: {', '.join([f'{float(x):.3e}' for x in S[: min(8, S.numel())]])}")
    print()

    # Tail coefficients for η(k)
    e_proj = (U.T @ e_w).detach()
    e_perp_sq = float((e_w.norm() ** 2 - e_proj.norm() ** 2).clamp(min=0.0).item())

    # ============================================================
    # Choose radius r from the top-k_max quadratic LS solution
    # ============================================================
    k_max = max(K_LIST) if K_LIST else 0
    if k_max > 0:
        V_top_max = Vh[:k_max, :].T.contiguous()  # (P, k)
        Bk_max = B @ V_top_max  # (M, k)
        alpha_ls_max = torch.linalg.lstsq(Bk_max, e_w).solution.reshape(-1).detach()
        delta_ls_norm_max = float(alpha_ls_max.norm())
    else:
        delta_ls_norm_max = 0.0

    r = max(RADIUS_MIN, RADIUS_MULT * delta_ls_norm_max)
    print("== Local radius ==")
    print(f"||alpha_ls||(k_max={k_max}) = {delta_ls_norm_max:.6e}")
    print(f"radius r = max({RADIUS_MIN:g}, {RADIUS_MULT:g} * ||alpha_ls||) = {r:.6e}")
    print()

    # ============================================================
    # Per-k subspace optimization: actual CE loss vs quadratic prediction
    # ============================================================
    print("== Results (held-out CE) ==")
    header = (
        "k | eta(k)  | CE_pred   | CE_top     | CE_rand    | top-pred | rand-top | ||δ_top|| | ||δ_rand||"
    )
    print(header)
    print("-" * len(header))

    results = {
        "seed": SEED,
        "device": device.type,
        "dtype": "float64",
        "d_in": D_IN,
        "n_classes": N_CLASSES,
        "w_teacher": W_TEACHER,
        "w_student": W_STUDENT,
        "teacher_temp": TEACHER_TEMP,
        "n_train": N_TRAIN,
        "n_test": N_TEST,
        "train_steps": TRAIN_STEPS,
        "lr": LR,
        "subspace_steps": SUBSPACE_STEPS,
        "subspace_lr": SUBSPACE_LR,
        "P_student": P_STUD,
        "base_test_ce": base_loss,
        "e_w_norm_sq": float(e_w_norm_sq),
        "radius_r": float(r),
        "pinv_tol": PINV_TOL,
        "k_list": K_LIST,
        "rows": [],
    }

    for k in K_LIST:
        if k == 0:
            eta_sq = float((e_proj * e_proj).sum().item() + e_perp_sq)
            eta = math.sqrt(max(0.0, eta_sq))
            q_min = 0.0
            ce_pred = base_loss
            ce_top = base_loss
            ce_rand = base_loss
            delta_top_norm = 0.0
            delta_rand_norm = 0.0
        else:
            V_top = Vh[:k, :].T.contiguous()  # (P,k)

            G = torch.randn((P_STUD, k), device=device, dtype=DTYPE)
            Q, _ = torch.linalg.qr(G, mode="reduced")
            V_rand = Q  # (P,k), orthonormal

            # η(k) tail in task-singular basis of B
            tail = e_proj[k:]
            eta_sq = float((tail * tail).sum().item() + e_perp_sq)
            eta = math.sqrt(max(0.0, eta_sq))

            # Quadratic-model minimum delta in top-k subspace:
            #   q_min(k) = min_{δ in span(V_top)} g^T δ + 1/2 δ^T (J^T G J) δ
            #           = 0.5(η(k)^2 - ||e_w||^2)
            q_min = 0.5 * (eta_sq - e_w_norm_sq)
            ce_pred = base_loss + q_min

            # Quadratic LS initialization in each subspace: solve min ||e_w - B V α||^2.
            B_top = B @ V_top
            alpha_top = torch.linalg.lstsq(B_top, e_w).solution.reshape(-1).detach()
            if float(alpha_top.norm()) > r:
                alpha_top = alpha_top * (r / (float(alpha_top.norm()) + 1e-30))

            B_rand = B @ V_rand
            alpha_rand = torch.linalg.lstsq(B_rand, e_w).solution.reshape(-1).detach()
            if float(alpha_rand.norm()) > r:
                alpha_rand = alpha_rand * (r / (float(alpha_rand.norm()) + 1e-30))

            # Nonlinear refinement in top-k (actual CE)
            alpha_top = alpha_top.clone().detach().requires_grad_(True)
            opt_top = torch.optim.Adam([alpha_top], lr=SUBSPACE_LR)
            best_top = None
            best_top_alpha = None
            for _ in range(SUBSPACE_STEPS):
                opt_top.zero_grad(set_to_none=True)
                th = theta_star + V_top @ alpha_top
                logits = (
                    torch.tanh(X_test @ th[sw1_s:sw1_e].reshape(W_STUDENT, D_IN).T + th[sb1_s:sb1_e])
                    @ th[sw2_s:sw2_e].reshape(N_CLASSES, W_STUDENT).T
                    + th[sb2_s:sb2_e]
                )
                loss_top = -(p_test * torch.log_softmax(logits, dim=-1)).sum(dim=-1).mean()
                loss_top.backward()
                opt_top.step()
                with torch.no_grad():
                    nrm = alpha_top.norm()
                    if float(nrm) > r:
                        alpha_top.mul_(r / (float(nrm) + 1e-30))
                    cur = float(loss_top.detach())
                    if best_top is None or cur < best_top:
                        best_top = cur
                        best_top_alpha = alpha_top.detach().clone()

            # Nonlinear refinement in random-k (actual CE)
            alpha_rand = alpha_rand.clone().detach().requires_grad_(True)
            opt_rand = torch.optim.Adam([alpha_rand], lr=SUBSPACE_LR)
            best_rand = None
            best_rand_alpha = None
            for _ in range(SUBSPACE_STEPS):
                opt_rand.zero_grad(set_to_none=True)
                th = theta_star + V_rand @ alpha_rand
                logits = (
                    torch.tanh(X_test @ th[sw1_s:sw1_e].reshape(W_STUDENT, D_IN).T + th[sb1_s:sb1_e])
                    @ th[sw2_s:sw2_e].reshape(N_CLASSES, W_STUDENT).T
                    + th[sb2_s:sb2_e]
                )
                loss_rand = -(p_test * torch.log_softmax(logits, dim=-1)).sum(dim=-1).mean()
                loss_rand.backward()
                opt_rand.step()
                with torch.no_grad():
                    nrm = alpha_rand.norm()
                    if float(nrm) > r:
                        alpha_rand.mul_(r / (float(nrm) + 1e-30))
                    cur = float(loss_rand.detach())
                    if best_rand is None or cur < best_rand:
                        best_rand = cur
                        best_rand_alpha = alpha_rand.detach().clone()

            ce_top = float(best_top)
            ce_rand = float(best_rand)
            delta_top_norm = float((V_top @ best_top_alpha).norm()) if best_top_alpha is not None else float("nan")
            delta_rand_norm = float((V_rand @ best_rand_alpha).norm()) if best_rand_alpha is not None else float("nan")

        print(
            f"{k:2d} | {eta:7.3e} | {ce_pred:8.6f} | {ce_top:9.6f} | {ce_rand:9.6f} | "
            f"{(ce_top - ce_pred):+.2e} | {(ce_rand - ce_top):+.2e} | {delta_top_norm:8.2e} | {delta_rand_norm:9.2e}"
        )

        results["rows"].append(
            {
                "k": int(k),
                "eta": float(eta),
                "eta_sq": float(eta_sq),
                "q_min_pred": float(q_min),
                "ce_pred": float(ce_pred),
                "ce_top": float(ce_top),
                "ce_rand": float(ce_rand),
                "ce_top_minus_pred": float(ce_top - ce_pred),
                "ce_rand_minus_top": float(ce_rand - ce_top),
                "delta_top_norm": float(delta_top_norm),
                "delta_rand_norm": float(delta_rand_norm),
            }
        )

    print()

    if OUT_JSON:
        os.makedirs(os.path.dirname(OUT_JSON) or ".", exist_ok=True)
        with open(OUT_JSON, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2)
        print(f"wrote: {OUT_JSON}")

    if SAVE_PLOT:
        import matplotlib.pyplot as plt

        ks = [row["k"] for row in results["rows"]]
        pred = [row["ce_pred"] for row in results["rows"]]
        top = [row["ce_top"] for row in results["rows"]]
        rand = [row["ce_rand"] for row in results["rows"]]

        plt.figure(figsize=(7.2, 4.8))
        plt.plot(ks, pred, "-o", label="quadratic pred (Fisher pullback)")
        plt.plot(ks, top, "-o", label="actual CE (top-k pullback)")
        plt.plot(ks, rand, "-o", label="actual CE (random k-subspace)")
        plt.axhline(base_loss, color="k", linestyle="--", linewidth=1, alpha=0.5, label="base CE")
        plt.xlabel("k (subspace dimension)")
        plt.ylabel("held-out soft CE loss")
        plt.title(f"CE local anchor (seed={SEED}, r={r:.2e})")
        plt.grid(True, alpha=0.25)
        plt.legend(loc="best", fontsize=9)
        plt.tight_layout()

        os.makedirs(os.path.dirname(OUT_PNG) or ".", exist_ok=True)
        plt.savefig(OUT_PNG, dpi=160)
        plt.close()
        print(f"wrote: {OUT_PNG}")

