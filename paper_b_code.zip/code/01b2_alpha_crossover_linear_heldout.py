"""
Linear-quadratic held-out α-crossover experiment (controlled; strongest anchor)
==============================================================================

This script implements the exact 1–4 protocol in a setting where the theory's
local-quadratic assumptions hold *exactly* (no "deep learning" confounders).

Setup:
  - Support operator A_s ∈ R^{n_s × p}, test operator A_t ∈ R^{n_t × p}
  - Metric M := (1/n_s) A_s^T A_s  (SPD w.h.p. if n_s >> p)
  - Source condition residual (Paper C SC(α,g) with G=I):
      e_s = A_s M^{-α} g,   e_t = A_t M^{-α} g
    with random g.
  - Training objective (squared loss, θ*=0):
      L(θ) = 1/2 ||A_s θ - e_s||^2

Protocol:
  1) α̂ estimation from support gradient:
       grad = ∇_θ L(0) = -A_s^T e_s / n_s
       ĉ_i^2 = |⟨grad, w_i⟩|^2 / λ_i
       slope(log ĉ_i^2 vs log λ_i) => α̂
  2) Predict top-k vs bottom-k by α̂ < 1/2 or α̂ > 1/2.
  3) Held-out verification:
       Fit θ constrained to top-k eigenspace vs bottom-k eigenspace (least squares),
       then evaluate MSE on the held-out operator A_t.
  4) Prediction accuracy > chance (0.5) supports the causal mechanism.
"""

from __future__ import annotations

import argparse
import math
import time

import numpy as np
import torch


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--p", type=int, default=160, help="Parameter dimension.")
    parser.add_argument("--n_support", type=int, default=800)
    parser.add_argument("--n_test", type=int, default=800)
    parser.add_argument("--k", type=int, default=16)
    parser.add_argument("--trials", type=int, default=50)
    parser.add_argument("--alpha_lo", type=float, default=-0.2)
    parser.add_argument("--alpha_hi", type=float, default=1.2)
    parser.add_argument("--neutral_gap", type=float, default=0.05, help="Exclude |alpha-0.5| < gap by resampling.")
    args = parser.parse_args()

    rng = np.random.default_rng(args.seed)
    torch.manual_seed(args.seed)

    if args.k <= 0:
        raise ValueError("--k must be positive")
    if args.p <= 0:
        raise ValueError("--p must be positive")
    if args.n_support <= args.p + 5:
        raise ValueError("--n_support should be > p for SPD M")

    t0 = time.time()
    n_scored = 0
    n_correct = 0

    for trial in range(args.trials):
        A_s = torch.randn(args.n_support, args.p)
        A_t = torch.randn(args.n_test, args.p)

        # Metric M = (1/n) A^T A
        M = (A_s.T @ A_s) / float(args.n_support)
        eigvals, eigvecs = torch.linalg.eigh(M)
        order = torch.argsort(eigvals, descending=True)
        eigvals = eigvals[order]
        eigvecs = eigvecs[:, order]

        # Resample alpha away from 0.5 to keep a crisp prediction task.
        alpha_true = float(rng.uniform(args.alpha_lo, args.alpha_hi))
        while abs(alpha_true - 0.5) < args.neutral_gap:
            alpha_true = float(rng.uniform(args.alpha_lo, args.alpha_hi))

        g = torch.randn(args.p)
        g_hat = eigvecs.T @ g

        lam = eigvals.clamp(min=1e-12)
        v = eigvecs @ (lam.pow(-alpha_true) * g_hat)  # v = M^{-α} g

        e_s = A_s @ v
        e_t = A_t @ v

        # (1) α̂ estimation from support gradient at θ=0.
        grad = -(A_s.T @ e_s) / float(args.n_support)
        grad_hat = eigvecs.T @ grad
        c2_hat = (grad_hat**2) / (lam + 1e-12)

        lam_np = lam.numpy()
        c2_np = c2_hat.numpy()
        mask = (lam_np > 1e-10) & (c2_np > 1e-20)
        if int(mask.sum()) < 10:
            continue

        x = np.log(lam_np[mask])
        y = np.log(c2_np[mask])
        slope_hat, intercept_hat = np.polyfit(x, y, 1)
        alpha_hat = float((1.0 - slope_hat) / 2.0)

        predicted = "top-k" if alpha_hat < 0.5 else "bottom-k"
        truth = "top-k" if alpha_true < 0.5 else "bottom-k"

        # (3) Held-out verification: fit in each subspace on support, eval on test.
        k = min(args.k, args.p // 2)
        V_top = eigvecs[:, :k]
        V_bot = eigvecs[:, -k:]

        Z_top = A_s @ V_top
        Z_bot = A_s @ V_bot
        a_top = torch.linalg.lstsq(Z_top, e_s).solution
        a_bot = torch.linalg.lstsq(Z_bot, e_s).solution

        pred_t_top = (A_t @ V_top) @ a_top
        pred_t_bot = (A_t @ V_bot) @ a_bot
        mse_top = torch.mean((pred_t_top - e_t) ** 2).item()
        mse_bot = torch.mean((pred_t_bot - e_t) ** 2).item()

        actual = "top-k" if mse_top < mse_bot else "bottom-k"

        ok = (predicted == actual)
        n_correct += int(ok)
        n_scored += 1

        if (trial + 1) % max(1, args.trials // 10) == 0 or trial < 3:
            print(
                f"[{trial+1:3d}/{args.trials}] "
                f"alpha_true={alpha_true:+.3f} alpha_hat={alpha_hat:+.3f} "
                f"pred={predicted:8s} truth={truth:8s} actual={actual:8s} "
                f"mse_top={mse_top:.3e} mse_bot={mse_bot:.3e} "
                f"{'OK' if ok else 'NO'}"
            )

    acc = (n_correct / n_scored) if n_scored else float("nan")
    if n_scored:
        tail = 0.0
        for i in range(n_correct, n_scored + 1):
            tail += math.comb(n_scored, i) * (0.5**i) * (0.5 ** (n_scored - i))
        pval = min(max(tail, 0.0), 1.0)
    else:
        pval = float("nan")

    print("\n" + "=" * 72)
    print("LINEAR α-CROSSOVER HELD-OUT SUMMARY")
    print("=" * 72)
    print(f"scored_trials: {n_scored}/{args.trials}")
    print(f"prediction_accuracy: {n_correct}/{n_scored} = {acc:.3f}")
    if n_scored:
        print(f"binomial_pvalue(one-sided, >0.5): {pval:.3g}")
    print(f"elapsed: {time.time()-t0:.1f}s")


if __name__ == "__main__":
    main()

