# Paper B Empirical Package

Reproducibility package for the empirical experiments released with the ECC paper series.

Public series note: the current paper chain is `A -> B -> D`. This package is the empirical package that should be shipped with Paper B. The older internal label `A / B / C` is retained only in some historical filenames.

## Directory Structure

```
experiment_package/
├── README.md
├── code/
│   ├── 01_alpha_crossover_controlled.py        # Exp①a: synthetic α-crossover
│   ├── 01b_alpha_crossover_teacher_student.py   # Exp①b: teacher-student held-out (digits+MLP)
│   ├── 01c_gpt2_alpha_crossover_heldout.py      # Exp①c: GPT-2 held-out α-crossover
│   ├── 02_gpt2_subspace_intervention.py        # Exp②: GPT-2 intervention (v2, deprecated)
│   ├── 02b_gpt2_intervention_v3_leakagefree.py # Exp②v3: leakage-free 3-way split (4 domains)
│   ├── 02c_gpt2_tier3_correlation.py           # Exp②v4: Tier-3 correlation (8 domains)
│   ├── 03a_local_bridge_mse.py                 # Exp③: Gold Anchor (MSE)
│   └── 03b_local_bridge_ce.py                  # Exp③: Gold Anchor (CE)
├── results/
│   ├── local_bridge_anchor_seed{0..4}.json
│   ├── local_bridge_anchor_ce_seed{0..4}.json
│   ├── gpt2_alpha_crossover_taskmetric.json     # Exp①c raw output
│   └── alpha_teacher_digits.json                # Exp①b raw output
└── figures/
    ├── 01_alpha_crossover.png
    ├── 02_gpt2_intervention.png
    ├── 03a_local_bridge_mse.png
    └── 03b_local_bridge_ce.png
```

## Requirements

```
python >= 3.10
torch >= 2.0
transformers >= 4.30
numpy
matplotlib
scipy
```

## How to Run

### Experiment ① Controlled α-Crossover
```bash
python code/01_alpha_crossover_controlled.py        # 1a: algebraic consistency
python code/01b_alpha_crossover_teacher_student.py   # 1b: teacher-student held-out
python code/01c_gpt2_alpha_crossover_heldout.py \     # 1c: GPT-2 held-out
  --metric_mode task --seeds 0,1,2 --metric_n 25 \
  --task_n 70 --alpha_n 10 --eval_n 8 --k 8 \
  --steps 20 --lr 0.003 --neutral_band 0.05 --min_r2 0.1
```

### Experiment ② GPT-2 Subspace Intervention (recommended: v4)
```bash
# v4 (recommended): 8 domains, leakage-free, Tier-3 correlation analysis
python code/02c_gpt2_tier3_correlation.py

# v3: 4 domains, leakage-free 3-way split
python code/02b_gpt2_intervention_v3_leakagefree.py

# v2 (deprecated): original version with leakage issue
python code/02_gpt2_subspace_intervention.py
```

### Experiment ③ Gold Anchor (MSE)
```bash
SEED=0 python code/03a_local_bridge_mse.py
# Run for seeds 0-4 for full results
```

### Experiment ③ Gold Anchor (CE)
```bash
SEED=0 python code/03b_local_bridge_ce.py
```

## Summary of Results

| Experiment | Claim Tested | Result |
|------------|-------------|--------|
| ① α-Crossover | Crossover at α=0.5 | Exact crossover, algebraic consistency confirmed |
| ② GPT-2 (v4) | Energy gap predicts improvement | r_s=0.786, p=0.021; 18/24 wins (8 domains) |
| ③a Gold Anchor MSE | η_T(k) bounds hold | 0/40 bound violations (5 seeds × 8 k) |
| ③b Gold Anchor CE | Theory extends to G_T≠I | <0.25% prediction error |

## Changelog

- **v2.2 → v3**: Fixed train/eval leakage in Exp②. Added strict 3-way split (support/train/eval).
- **v3 → v4**: Extended to 8 domains. Added Tier-3 causative test: Spearman correlation between energy gap and improvement magnitude (r=0.786, p=0.021).
