# Paper D Reproducibility Package

This is the paper-facing release package for:

**Consensus-Target Linear Shrinkage: The Geometry of In-Context Learning in the Gradient-Gram Space**

Use this directory for the website and public release. It mirrors the final paper's title, table values, and artifact organization.

## Canonical Rule

- The canonical statement of claims is the manuscript: [`../paper_d.tex`](../paper_d.tex)
- The canonical public releases are [`../paper_d.pdf`](../paper_d.pdf) and [`../../github_pages/paper_d.html`](../../github_pages/paper_d.html)
- This directory mirrors the paper-facing tables and links them to the raw experiment files retained elsewhere in `paper_d/`

## Contents

- [`paper_tables.json`](./paper_tables.json): machine-readable mirror of the paper-facing tables
- [`table_cross_model.csv`](./table_cross_model.csv): Table 1 style 8-model summary used in the manuscript
- [`table_compression_fits.csv`](./table_compression_fits.csv): per-task compression fits reported in the manuscript
- [`table_reward_slopes.csv`](./table_reward_slopes.csv): task-dependent reward slopes reported in the manuscript

## Artifact Map

### Canonical paper-facing tables

- Cross-model universality: [`table_cross_model.csv`](./table_cross_model.csv)
- Compression-vs-`alpha_P` fits: [`table_compression_fits.csv`](./table_compression_fits.csv)
- Task-dependent reward slopes: [`table_reward_slopes.csv`](./table_reward_slopes.csv)

### Raw and audit data

- Large verification sweeps: [`../15_theorem_verification/`](../15_theorem_verification/)
- Raw 65-condition sweep: [`../15_theorem_verification/alpha_sweep_results.jsonl`](../15_theorem_verification/alpha_sweep_results.jsonl)
- Raw 8-model sweep: [`../15_theorem_verification/cross_model_results.json`](../15_theorem_verification/cross_model_results.json)
- Majorization and overlap checks: [`../15_theorem_verification/majorization_results.json`](../15_theorem_verification/majorization_results.json), [`../15_theorem_verification/spectral_overlap_results.json`](../15_theorem_verification/spectral_overlap_results.json)

## Interpretation Notes

- The public package follows the paper's final tables, not every broader exploratory sweep stored in the repository.
- The compression-fit table in the paper corresponds to the positive-shot sweep conditions (`n_examples > 0`) from `alpha_sweep_results.jsonl`.
- The raw verification directory is still useful for audit, but it contains auxiliary conditions such as `irrelevant` and `0-shot`, so it should not be treated as a paper table source without the subset definition.
- The cross-model JSON in `15_theorem_verification/` is kept as raw audit output. The website-facing package mirrors the manuscript's final 8-model summary directly in `table_cross_model.csv`.

## Recommended Release Bundle

For the homepage or repository release, publish these together:

1. [`../paper_d.pdf`](../paper_d.pdf)
2. [`../../github_pages/paper_d.html`](../../github_pages/paper_d.html)
3. this directory
4. [`../15_theorem_verification/README.md`](../15_theorem_verification/README.md)
